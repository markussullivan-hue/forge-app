// Ports /context/linked-classic-app/src/GovernanceReviewPage.rsx +
// reviewResultContainer.rsx (and supporting JS queries) to a React page.

import { useMemo, useState, type ChangeEvent } from 'react'
import { toast } from 'sonner'
import { Card, CardContent, CardHeader, CardTitle } from '../lib/shadcn/card'
import { Button } from '../lib/shadcn/button'
import { Label } from '../lib/shadcn/label'
import { Textarea } from '../lib/shadcn/textarea'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '../lib/shadcn/select'
import { useBackendFunction } from '../hooks/useBackendFunction'
import {
  aiRelevanceOptions,
  materialTypeOptions,
  methodologyLensOptions,
} from './governance/options'
import { reviewInputValidation } from './governance/validation'
import ReviewResult from './governance/ReviewResult'
import DocumentUpload, { type UploadedDocumentMeta } from './governance/DocumentUpload'
import {
  buildGovernanceReviewCopyMarkdown,
  buildGovernanceReviewMarkdownExport,
  copyMarkdownToClipboard,
  downloadMarkdown,
  normaliseReviewResult,
  type DisplayModel,
} from './governance/exportMarkdown'

type RunStatus = 'idle' | 'running' | 'complete' | 'error'

function captureFromWorkflowBody(body: unknown): unknown {
  if (!body || typeof body !== 'object') return null
  const b = body as Record<string, unknown>
  const data = (b['data'] as Record<string, unknown> | undefined) ?? undefined
  return (
    b['result'] ||
    b['display'] ||
    b['display_model'] ||
    data?.['result'] ||
    data?.['display'] ||
    data?.['display_model'] ||
    null
  )
}

export default function GovernanceReviewPage() {
  // ---- Form state -----------------------------------------------------
  const [methodologyLens, setMethodologyLens] = useState<string>('general')
  const [materialType, setMaterialType] = useState<string>('')
  const [aiRelevance, setAiRelevance] = useState<string>('possibly_ai_relevant')
  const [governanceText, setGovernanceText] = useState<string>('')

  // ---- Run state ------------------------------------------------------
  const [runStatus, setRunStatus] = useState<RunStatus>('idle')
  const [governanceReviewResult, setGovernanceReviewResult] = useState<DisplayModel | null>(null)
  const [currentGovernanceReviewId, setCurrentGovernanceReviewId] = useState<string | null>(null)
  const [activeGovernanceReviewIdState, setActiveGovernanceReviewIdState] = useState<string | null>(
    null,
  )
  const [uploadedDocument, setUploadedDocument] = useState<UploadedDocumentMeta | null>(null)

  const validation = useMemo(
    () =>
      reviewInputValidation({
        methodologyLens,
        materialType,
        aiRelevance,
        governanceText,
      }),
    [methodologyLens, materialType, aiRelevance, governanceText],
  )

  // ---- Backend hooks --------------------------------------------------
  const prepareRun = useBackendFunction('/backend/governance/prepareGovernanceReviewRun.ts')
  const runWorkflow = useBackendFunction('/backend/governance/runGovernanceReviewWorkflow.ts')
  const getResult = useBackendFunction('/backend/governance/getGovernanceReviewResult.ts')

  const isRunning = runStatus === 'running'
  const canRunButton = validation.canRun && !isRunning

  // ---- Handlers -------------------------------------------------------
  const handleClear = () => {
    setMethodologyLens('general')
    setMaterialType('')
    setAiRelevance('possibly_ai_relevant')
    setGovernanceText('')
    setGovernanceReviewResult(null)
    setCurrentGovernanceReviewId(null)
    setActiveGovernanceReviewIdState(null)
    setUploadedDocument(null)
    setRunStatus('idle')
  }

  const handleDocumentExtracted = (text: string, meta: UploadedDocumentMeta) => {
    setGovernanceText(text)
    setUploadedDocument(meta)
    onInputChanged()
  }

  const handleRemoveUpload = () => {
    setUploadedDocument(null)
    setGovernanceText('')
    onInputChanged()
  }

  // Clear only the result when inputs change (mirrors classic
  // clearGovernanceReviewResultOnly).
  const onInputChanged = () => {
    if (governanceReviewResult) setGovernanceReviewResult(null)
    if (runStatus === 'complete' || runStatus === 'error') setRunStatus('idle')
  }

  const handleRun = async () => {
    // 1) Re-run validation.
    if (!validation.canRun) {
      const description = validation.errors.length
        ? validation.errors.join('\n')
        : 'Complete the required fields before running the governance review.'
      toast.warning('Review not ready', { description })
      return
    }

    setRunStatus('running')
    setGovernanceReviewResult(null)
    toast.info('Governance review started', {
      description: 'FORGE is reviewing the pasted governance material.',
    })

    try {
      // 2) Prepare the run — mints a review_id (no DB row yet).
      const prepared = (await prepareRun.trigger({}).result) as
        | { review_id?: string; prepared_at?: string }
        | null
      const reviewId = prepared?.review_id ?? ''
      if (!reviewId) {
        throw new Error('prepareGovernanceReviewRun did not return a review_id.')
      }
      setCurrentGovernanceReviewId(reviewId)
      setActiveGovernanceReviewIdState(reviewId)

      // 3) POST to the governance workflow webhook.
      const workflowBody = await runWorkflow.trigger({
        reviewId,
        materialType,
        aiRelevance,
        methodologyLens,
        governanceText,
      }).result

      // 4) Pull the stored row (if the workflow wrote it).
      let storedRow: Record<string, unknown> | null = null
      try {
        storedRow = (await getResult.trigger({ reviewId }).result) as
          | Record<string, unknown>
          | null
      } catch {
        storedRow = null
      }

      // 5) Capture display from: workflow body → stored row.result_json → stored row.
      let captured = captureFromWorkflowBody(workflowBody)
      if (!captured && storedRow) {
        captured = storedRow['result_json'] ?? storedRow
      }

      if (!captured) {
        setRunStatus('error')
        toast.warning('Review completed', {
          description: 'The review ran, but no display/export result object was captured.',
        })
        return
      }

      const display = normaliseReviewResult(captured)
      setGovernanceReviewResult(display)
      setRunStatus('complete')
      toast.success('Governance review complete', {
        description: 'The review result is ready.',
      })
    } catch (err) {
      const message =
        err instanceof Error ? err.message : String(err ?? 'The governance review failed.')
      setGovernanceReviewResult(null)
      setRunStatus('error')
      toast.error('Governance review failed', { description: message })
    }
  }

  const handleCopyMarkdown = async () => {
    if (!governanceReviewResult) {
      toast.warning('No review available', {
        description: 'Run a governance review before copying the export.',
      })
      return
    }
    const text = buildGovernanceReviewCopyMarkdown(governanceReviewResult)
    if (!text.trim()) {
      toast.warning('Nothing to copy', { description: 'No review summary is available yet.' })
      return
    }
    const ok = await copyMarkdownToClipboard(text)
    if (ok) {
      toast.success('Review copied', {
        description: 'The buyer-friendly governance review has been copied to your clipboard.',
      })
    } else {
      toast.error('Copy failed', { description: 'Could not write to clipboard.' })
    }
  }

  const handleDownloadMarkdown = () => {
    if (!governanceReviewResult) {
      toast.warning('No review available', {
        description: 'Run a governance review before exporting the markdown file.',
      })
      return
    }
    const payload = buildGovernanceReviewMarkdownExport(governanceReviewResult)
    downloadMarkdown(payload)
    toast.success('Export downloaded', { description: payload.fileName })
  }

  // ---- Validation message line ---------------------------------------
  const validationMessage = (() => {
    if (validation.errors.length) {
      return validation.errors.map((e) => `• ${e}`).join('\n')
    }
    if (validation.warnings.length) {
      return validation.warnings.map((w) => `• ${w}`).join('\n')
    }
    if (validation.canRun) return 'Ready to review.'
    return 'Complete the required fields to run the review.'
  })()

  const validationTone = validation.errors.length
    ? 'text-destructive'
    : validation.warnings.length
      ? 'text-amber-600 dark:text-amber-400'
      : 'text-muted-foreground'

  return (
    <div className="max-w-5xl mx-auto p-6 space-y-6">
      <div className="space-y-1">
        <h1 className="text-2xl font-bold tracking-tight">Governance Review</h1>
        <p className="text-sm text-muted-foreground">
          Paste a governance pack, business case, charter or steering paper and FORGE will return a
          structured review.
        </p>
      </div>

      {/* Initial Information */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Initial Information</CardTitle>
        </CardHeader>
        <CardContent className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="space-y-1.5">
            <Label>Methodology / governance lens</Label>
            <Select
              value={methodologyLens}
              onValueChange={(v) => {
                setMethodologyLens(v)
                onInputChanged()
              }}
            >
              <SelectTrigger>
                <SelectValue placeholder="Select an option" />
              </SelectTrigger>
              <SelectContent>
                {methodologyLensOptions.map((opt) => (
                  <SelectItem key={opt.value} value={opt.value}>
                    {opt.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-1.5">
            <Label>Material type</Label>
            <Select
              {...(materialType ? { value: materialType } : {})}
              onValueChange={(v) => {
                setMaterialType(v)
                onInputChanged()
              }}
            >
              <SelectTrigger>
                <SelectValue placeholder="Select an option" />
              </SelectTrigger>
              <SelectContent>
                {materialTypeOptions.map((opt) => (
                  <SelectItem key={opt.value} value={opt.value}>
                    {opt.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-1.5">
            <Label>AI relevance</Label>
            <Select
              value={aiRelevance}
              onValueChange={(v) => {
                setAiRelevance(v)
                onInputChanged()
              }}
            >
              <SelectTrigger>
                <SelectValue placeholder="Select an option" />
              </SelectTrigger>
              <SelectContent>
                {aiRelevanceOptions.map((opt) => (
                  <SelectItem key={opt.value} value={opt.value}>
                    {opt.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Upload document */}
      <DocumentUpload
        hasExistingText={governanceText.trim().length > 0}
        uploadedDocument={uploadedDocument}
        onExtracted={handleDocumentExtracted}
        onClear={handleRemoveUpload}
        disabled={isRunning}
      />

      {/* Paste governance text */}
      <Card>
        <CardContent className="pt-6 space-y-3">
          <div className="space-y-1.5">
            <Label>
              Paste governance text <span className="text-destructive">*</span>
            </Label>
            <Textarea
              required
              value={governanceText}
              placeholder="Paste the governance pack, business case, charter, PID, steering paper or assurance material here — or upload a document above."
              onChange={(e: ChangeEvent<HTMLTextAreaElement>) => {
                setGovernanceText(e.target.value)
                // Typing edits invalidate the uploaded-file association.
                if (uploadedDocument) setUploadedDocument(null)
                onInputChanged()
              }}
              className="min-h-[200px] font-mono text-xs"
            />
            <div className="flex items-center justify-between text-xs text-muted-foreground">
              <span>
                {validation.characterCount} characters · {validation.wordCount} words
              </span>
            </div>
          </div>

          <pre className={`whitespace-pre-wrap text-sm leading-relaxed ${validationTone}`}>
            {validationMessage}
          </pre>

          <div className="flex flex-wrap items-center gap-3">
            <Button onClick={handleRun} disabled={!canRunButton}>
              {isRunning ? 'Reviewing…' : 'Review governance pack'}
            </Button>
            <Button variant="outline" onClick={handleClear} disabled={isRunning}>
              Clear Data
            </Button>
            {isRunning ? (
              <span className="text-sm text-muted-foreground">Reviewing governance pack...</span>
            ) : null}
          </div>
        </CardContent>
      </Card>

      {/* Result panel + actions */}
      {runStatus === 'complete' && governanceReviewResult ? (
        <>
          <ReviewResult model={governanceReviewResult} />
          <div className="flex flex-wrap gap-3">
            <Button variant="outline" onClick={handleCopyMarkdown}>
              Copy Markdown
            </Button>
            <Button variant="outline" onClick={handleDownloadMarkdown}>
              Export / Download Markdown
            </Button>
            {currentGovernanceReviewId ? (
              <span className="self-center text-xs text-muted-foreground">
                Review id: <code className="font-mono">{currentGovernanceReviewId}</code>
              </span>
            ) : null}
          </div>
        </>
      ) : null}

      {runStatus === 'error' && !governanceReviewResult ? (
        <Card>
          <CardContent className="pt-6">
            <p className="text-sm text-destructive">
              The governance review failed. Check the validation message above, then try again.
            </p>
            {activeGovernanceReviewIdState ? (
              <p className="mt-2 text-xs text-muted-foreground">
                Last review id:{' '}
                <code className="font-mono">{activeGovernanceReviewIdState}</code>
              </p>
            ) : null}
          </CardContent>
        </Card>
      ) : null}
    </div>
  )
}
