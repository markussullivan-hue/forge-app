// Charter generation wizard. Mirrors classic
// /context/linked-classic-app/src/FORGECharterGenerationWizard.rsx +
// steppedContainerHomepage.rsx and runs the createProject + staged-generation
// flow.

import { useCallback, useEffect, useMemo, useRef, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { ChevronDown, Sparkles } from 'lucide-react'
import { toast } from 'sonner'
import { Button } from '../lib/shadcn/button'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '../lib/shadcn/dropdown-menu'
import { cn } from '../lib/shadcn/utils'
import { useBackendFunction } from '../hooks/useBackendFunction'
import { useGetCurrentUserId } from '../hooks/backend/auth'
import { useGetCreateServiceIndustryType } from '../hooks/backend/wizard/lookups'
import { useAppState } from '../utils/appState'
import { useSession } from '../utils/session'
import Step1Overview from './wizard/Step1Overview'
import Step2DimensionsScope, {
  isLifecycleStageVisible,
} from './wizard/Step2DimensionsScope'
import Step2ContextSystems from './wizard/Step2ContextSystems'
import Step3BusinessCaseDetail from './wizard/Step3BusinessCaseDetail'
import Step3Review from './wizard/Step3Review'
import { useGetDeliveryModelsForGroup } from '../hooks/backend/wizard/lookups'
import ConfirmGenerationModal from './wizard/ConfirmGenerationModal'
import { getPreset, type PresetKey } from './wizard/presets'
import {
  getWizardState,
  setWizardState,
  useWizardState,
  type WizardState,
} from './wizard/wizardState'
import {
  describeError,
  runArtefactsGeneration,
  runCreateProjectFlow,
} from './wizard/runGenerate'

const STEPS = [
  { num: 1, label: 'Overview' },
  { num: 2, label: 'Dimensions & Scope' },
  { num: 3, label: 'Context & Systems' },
  { num: 4, label: 'Business Case Detail' },
  { num: 5, label: 'Review' },
] as const

type WizardStep = 1 | 2 | 3 | 4 | 5

type DeliveryModelRow = {
  value: string
  label: string
  model_code: string | null
  group_code: string | null
}

const PRESETS: { key: PresetKey; label: string; helper: string }[] = [
  { key: 'minimal', label: 'Minimal', helper: 'Small idea · sparse inputs' },
  { key: 'typical', label: 'Typical', helper: 'Mid-sized · realistic baseline' },
  { key: 'regulated', label: 'Large regulated', helper: 'Enterprise · high-stakes' },
]

const TOTAL_STAGES = 8
const POLL_INTERVAL_MS = 3_000

// ---- Blocking-check helpers (ported from classic text12 / nextButton / generateButton)
function isBlank(v: unknown): boolean {
  if (v === null || v === undefined) return true
  if (typeof v === 'string') return v.trim() === ''
  if (Array.isArray(v)) return v.length === 0
  return false
}

function datesInvalid(start: string, end: string): boolean {
  if (!start || !end) return true
  const s = new Date(start)
  const e = new Date(end)
  if (Number.isNaN(s.getTime()) || Number.isNaN(e.getTime())) return true
  s.setHours(0, 0, 0, 0)
  e.setHours(0, 0, 0, 0)
  const minEnd = new Date(s)
  minEnd.setMonth(minEnd.getMonth() + 1)
  return e < minEnd
}

// Step 1 (Overview): initiative basics only.
function step1Invalid(ws: WizardState): boolean {
  return (
    isBlank(ws.initiativeName) ||
    isBlank(ws.initiativeDescription) ||
    isBlank(ws.initiativeBudget) ||
    isBlank(ws.initiativeTargetStartDate) ||
    isBlank(ws.initiativeTargetEndDate) ||
    isBlank(ws.initiativeServiceIndustrySelect) ||
    datesInvalid(ws.initiativeTargetStartDate, ws.initiativeTargetEndDate)
  )
}

// Step 2 (Dimensions & Scope): radios, drivers/functions, POTI x4, and
// lifecycle stage — lifecycle is only required when visible (the JSON's
// hiddenWhen rule masks it until a non-PROGRAMME_PORTFOLIO model is picked).
function step2Invalid(ws: WizardState, models: DeliveryModelRow[]): boolean {
  const lifecycleVisible = isLifecycleStageVisible(
    ws.preferredDeliveryModelSelect,
    models,
  )
  return (
    isBlank(ws.radioGroupScale) ||
    isBlank(ws.radioGroupComplexity) ||
    isBlank(ws.radioGroupReadiness) ||
    isBlank(ws.multiselectBusinessDrivers) ||
    isBlank(ws.multiselectImpactedFunctions) ||
    isBlank(ws.checkboxGroupPOTIProcesses) ||
    isBlank(ws.checkboxGroupPOTIOrganisation) ||
    isBlank(ws.checkboxGroupPOTITechnology) ||
    isBlank(ws.checkboxGroupPOTIInformation) ||
    (lifecycleVisible && isBlank(ws.selectLifeCycleStage))
  )
}

// Step 3 (Context & Systems): strategic objectives, business problem,
// delivery framework, and a populated systems selection.
function step3Invalid(ws: WizardState): boolean {
  const sel = ws.systemsSelection
  return (
    isBlank(ws.textInputBusinessProblem) ||
    isBlank(ws.textInputStrategicObjectives) ||
    isBlank(ws.deliveryModelGroupSelect) ||
    isBlank(ws.preferredDeliveryModelSelect) ||
    sel.length === 0 ||
    sel.some((r) => r.systemId === null && isBlank(r.customSystemName)) ||
    sel.some((r) => isBlank(r.impactBucketCode))
  )
}

// Step 4 (Business Case Detail) has no blocking validation — all optional.
function step4Invalid(_ws: WizardState): boolean {
  return false
}

// Step 5 (Review): aggregate of all blocking steps.
function step5Invalid(ws: WizardState, models: DeliveryModelRow[]): boolean {
  return step1Invalid(ws) || step2Invalid(ws, models) || step3Invalid(ws)
}

// ---- Page ----------------------------------------------------------------

export default function CharterGenerationWizardPage() {
const ws = useWizardState()
  const appState = useAppState()
  const session = useSession()
  const navigate = useNavigate()

  // ---- Hooks for backend functions used by the generate flow -----------
  // Delivery models needed both to drive lookups inside steps and to evaluate
  // the lifecycle visibility predicate at the page-level validation layer.
  const deliveryModelsQuery = useGetDeliveryModelsForGroup()
  useEffect(() => {
    if (ws.deliveryModelGroupSelect) {
      deliveryModelsQuery.trigger({ groupValue: ws.deliveryModelGroupSelect })
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [ws.deliveryModelGroupSelect])
  const modelRows = useMemo<DeliveryModelRow[]>(
    () => (deliveryModelsQuery.data ?? []) as DeliveryModelRow[],
    [deliveryModelsQuery.data],
  )

  const createProject = useBackendFunction('/backend/wizard/createProject.ts')
  const createProjectContext = useBackendFunction(
    '/backend/wizard/createProjectContext.ts',
  )
  const createProjectSystems = useBackendFunction(
    '/backend/wizard/createProjectSystems.ts',
  )
  const runStagedGenerationPipeline = useBackendFunction(
    '/backend/wizard/runStagedGenerationPipeline.ts',
  )
  const pollGenerationProgress = useBackendFunction(
    '/backend/wizard/pollGenerationProgress.ts',
  )
  const currentUserIdQuery = useGetCurrentUserId()
  const industries = useGetCreateServiceIndustryType()

  // Trigger user-id once on mount
useEffect(() => {
    currentUserIdQuery.trigger({ forgeUserId: session?.id ?? '' })
    industries.trigger()
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  // ---- Generate flow ---------------------------------------------------
  const [isCreating, setIsCreating] = useState(false)

  const startGenerateFlow = useCallback(async () => {
    if (step5Invalid(ws, modelRows)) {
      toast.error('Please complete all required fields before generating.')
      return
    }
    setIsCreating(true)
    try {
await runCreateProjectFlow({
        ws,
        industries: (industries.data ?? []) as Array<{ id: number; label: string }>,
        forgeUserId: session?.id ?? '',
        triggers: {
          createProject: createProject.trigger,
          createProjectContext: createProjectContext.trigger,
          createProjectSystems: createProjectSystems.trigger,
        },
      })
      // generationStatus is now 'confirming' — modal opens automatically.
    } catch (err) {
      const message = describeError(err, 'Could not create the project record.')
      ws.setWizardState({ generationStatus: 'error', generationError: message })
      toast.error(message)
    } finally {
      setIsCreating(false)
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [ws, industries.data])

  const handleConfirmGenerate = useCallback(async () => {
    const projectId = appState.createdProjectId
    const orgId = appState.createdOrgId
    if (!projectId || !orgId) {
      ws.setWizardState({
        generationStatus: 'error',
        generationError: 'Project IDs not available — please try the flow again.',
      })
      return
    }
    const userIdValue =
      (currentUserIdQuery.data as { userId?: string | null } | null)?.userId ?? null

    try {
      await runArtefactsGeneration({
        projectId,
        orgId,
        initiatedByUserId: userIdValue,
        triggers: { runStagedGenerationPipeline: runStagedGenerationPipeline.trigger },
      })
    } catch (err) {
      const message = describeError(err, 'Workflow trigger failed.')
      ws.setWizardState({ generationStatus: 'error', generationError: message })
      toast.error(message)
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [appState.createdProjectId, appState.createdOrgId, currentUserIdQuery.data])

  // ---- Poll while running ----------------------------------------------
  const pollTimerRef = useRef<number | null>(null)

  useEffect(() => {
    // Always clear any previous timer when status changes
    if (pollTimerRef.current !== null) {
      window.clearTimeout(pollTimerRef.current)
      pollTimerRef.current = null
    }

    if (ws.generationStatus !== 'running') return

    let cancelled = false

    const tick = async () => {
      const live = getWizardState()
      const projectId = appState.createdProjectId
      const orgId = appState.createdOrgId
      if (!projectId || !orgId) return
      try {
        const handle = pollGenerationProgress.trigger({
          orgId,
          projectId,
          runId: live.currentRunId ?? null,
          generationStartedAt: live.generationStartedAt ?? null,
        }) as { result: Promise<unknown> }
        const result = await handle.result
        if (cancelled) return
        const row = result as {
          run_id?: string | null
          status?: string | null
        } | null
        if (row?.run_id && row.run_id !== live.currentRunId) {
          setWizardState({ currentRunId: row.run_id })
        }
        const status = String(row?.status ?? '').toLowerCase()
        if (status === 'completed') {
          setWizardState({ generationStatus: 'complete', generationResult: row })
          return
        }
        if (status === 'failed') {
          setWizardState({
            generationStatus: 'error',
            generationError:
              (row as { error_message?: string | null } | null)?.error_message ??
              'Staged generation reported a failed status.',
          })
          return
        }
      } catch (err) {
        // Single tick failures are not fatal — keep polling until status settles.
        if (cancelled) return
        // eslint-disable-next-line no-console
        console.error('[wizard] poll tick failed', err)
      }
      if (!cancelled && getWizardState().generationStatus === 'running') {
        pollTimerRef.current = window.setTimeout(tick, POLL_INTERVAL_MS)
      }
    }

    // First tick is immediate; subsequent ticks are scheduled inside `tick`.
    void tick()

    return () => {
      cancelled = true
      if (pollTimerRef.current !== null) {
        window.clearTimeout(pollTimerRef.current)
        pollTimerRef.current = null
      }
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [ws.generationStatus])

  // ---- Fire success toast once on completion ---------------------------
  // Navigation to /charter is deferred until the user clicks Done in the
  // ConfirmGenerationModal so the Preview/Download PDF buttons are visible.
  const completedRef = useRef(false)
  useEffect(() => {
    if (ws.generationStatus === 'complete' && !completedRef.current) {
      completedRef.current = true
      toast.success(`${ws.initiativeName || 'Your governance pack'} is ready.`)
    }
    if (ws.generationStatus !== 'complete') {
      completedRef.current = false
    }
  }, [ws.generationStatus, ws.initiativeName])

  // ---- Stepper + prefill -----------------------------------------------
  const goToStep = (step: WizardStep) => ws.setWizardState({ currentStep: step })

  const handlePrefill = (key: PresetKey) => {
    ws.setWizardState(getPreset(key))
    toast.success(`Applied "${key}" prefill preset`)
  }

  // ---- Progress info from latest poll data -----------------------------
  const progressInfo = useMemo(() => {
    const data = pollGenerationProgress.data as {
      stages_done?: number
      current_stage?: string | null
    } | null
    return {
      stagesDone: data?.stages_done ?? 0,
      totalStages: TOTAL_STAGES,
      currentStage: data?.current_stage ?? null,
    }
  }, [pollGenerationProgress.data])

  const nextDisabled =
    isCreating ||
    (ws.currentStep === 1 && step1Invalid(ws)) ||
    (ws.currentStep === 2 && step2Invalid(ws, modelRows)) ||
    (ws.currentStep === 3 && step3Invalid(ws)) ||
    (ws.currentStep === 4 && step4Invalid(ws))

  const generateDisabled = isCreating || step5Invalid(ws, modelRows)

  return (
    <div className="max-w-5xl mx-auto p-6 lg:p-8 space-y-6">
      {/* Header */}
      <header className="space-y-2 text-center">
        <div className="inline-flex items-center justify-center gap-2">
          <Sparkles className="w-5 h-5 text-primary" />
          <span className="text-base font-bold tracking-tight">New initiative</span>
        </div>
        <p className="text-sm text-muted-foreground max-w-3xl mx-auto">
          Capture the essential inputs for a new initiative across five
          structured steps. Once confirmed, FORGE uses AI to shape the initial
          governance and delivery artefacts.
        </p>
      </header>

      {/* Stepper */}
      <Stepper currentStep={ws.currentStep} onStepClick={goToStep} />

      {/* Prefill */}
      <div className="flex items-center justify-between">
        <span className="text-xs text-muted-foreground">
          Step {ws.currentStep} of {STEPS.length} — {STEPS[ws.currentStep - 1]?.label}
        </span>
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button type="button" variant="outline" size="sm">
              Prefill
              <ChevronDown className="w-4 h-4 ml-1" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="w-64">
            {PRESETS.map((p) => (
              <DropdownMenuItem
                key={p.key}
                onSelect={(e) => {
                  e.preventDefault()
                  handlePrefill(p.key)
                }}
                className="flex flex-col items-start gap-0.5"
              >
                <span className="font-medium">{p.label}</span>
                <span className="text-xs text-muted-foreground">{p.helper}</span>
              </DropdownMenuItem>
            ))}
          </DropdownMenuContent>
        </DropdownMenu>
      </div>

      {/* Step body */}
      <div className="rounded-lg border border-border bg-card p-6">
        {ws.currentStep === 1 ? <Step1Overview /> : null}
        {ws.currentStep === 2 ? <Step2DimensionsScope /> : null}
        {ws.currentStep === 3 ? <Step2ContextSystems /> : null}
        {ws.currentStep === 4 ? <Step3BusinessCaseDetail /> : null}
        {ws.currentStep === 5 ? <Step3Review /> : null}
      </div>

      {/* Footer nav */}
      <div className="flex items-center justify-between">
        <Button
          type="button"
          variant="outline"
          disabled={ws.currentStep === 1 || isCreating}
          onClick={() => goToStep(Math.max(1, ws.currentStep - 1) as WizardStep)}
        >
          Back
        </Button>

        <div className="flex items-center gap-2">
          {ws.currentStep < 5 ? (
            <Button
              type="button"
              onClick={() => goToStep(Math.min(5, ws.currentStep + 1) as WizardStep)}
              disabled={nextDisabled}
            >
              Next
            </Button>
          ) : (
            <Button
              type="button"
              onClick={startGenerateFlow}
              disabled={generateDisabled}
            >
              <Sparkles className="w-4 h-4 mr-1" />
              {isCreating ? 'Preparing…' : 'Generate'}
            </Button>
          )}
        </div>
      </div>

      {/* Confirm/running/error/complete modal */}
      <ConfirmGenerationModal
        status={ws.generationStatus}
        initiativeName={ws.initiativeName}
        errorMessage={ws.generationError}
        progress={progressInfo}
        previewPdfUrl={
          (ws.generationResult as
            | { pdfmonkey_preview_url?: string | null }
            | null)?.pdfmonkey_preview_url ?? null
        }
        downloadPdfUrl={
          (ws.generationResult as
            | { pdfmonkey_download_url?: string | null }
            | null)?.pdfmonkey_download_url ?? null
        }
        onCancel={() => ws.setWizardState({ generationStatus: 'idle' })}
        onConfirm={handleConfirmGenerate}
        onRetry={handleConfirmGenerate}
        onClose={() => {
          const wasComplete = ws.generationStatus === 'complete'
          ws.setWizardState({ generationStatus: 'idle' })
          if (wasComplete) navigate('/charter')
        }}
      />
    </div>
  )
}

// ---- Sub-components -------------------------------------------------------

function Stepper({
  currentStep,
  onStepClick,
}: {
  currentStep: WizardStep
  onStepClick: (step: WizardStep) => void
}) {
  return (
    <ol className="flex items-center gap-2 justify-center">
      {STEPS.map((step, idx) => {
        const isActive = step.num === currentStep
        const isComplete = step.num < currentStep
        return (
          <li key={step.num} className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => onStepClick(step.num as WizardStep)}
              className={cn(
                'flex items-center justify-center gap-2 rounded-full px-3 py-1.5 text-sm transition-colors min-w-[12rem]',
                isActive
                  ? 'bg-primary text-primary-foreground'
                  : isComplete
                    ? 'bg-secondary text-secondary-foreground hover:bg-secondary/80'
                    : 'bg-muted text-muted-foreground hover:bg-muted/80',
              )}
            >
              <span
                className={cn(
                  'inline-flex items-center justify-center w-5 h-5 rounded-full text-xs font-semibold',
                  isActive
                    ? 'bg-primary-foreground text-primary'
                    : 'bg-background text-foreground',
                )}
              >
                {step.num}
              </span>
              <span className="font-medium">{step.label}</span>
            </button>
            {idx < STEPS.length - 1 ? (
              <span
                className={cn(
                  'h-px w-8',
                  step.num < currentStep ? 'bg-primary' : 'bg-border',
                )}
              />
            ) : null}
          </li>
        )
      })}
    </ol>
  )
}
