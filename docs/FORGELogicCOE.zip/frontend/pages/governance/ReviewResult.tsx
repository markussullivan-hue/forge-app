// Ports /context/linked-classic-app/src/reviewResultContainer.rsx — the read-out
// of a completed governance review. Renders sections from a DisplayModel using
// the in-tree Markdown renderer.

import { Markdown } from '../charter/markdown'
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '../../lib/shadcn/table'
import { Card, CardHeader, CardTitle, CardContent } from '../../lib/shadcn/card'
import type { DisplayModel } from './exportMarkdown'

function asString(value: unknown): string {
  if (value === null || value === undefined) return ''
  if (typeof value === 'string') return value
  return String(value)
}

function weaknessesMarkdown(items: unknown[]): string {
  if (!items.length) return 'No decisive weaknesses returned.'
  return items
    .map((raw, index) => {
      const item = (raw as Record<string, unknown>) ?? {}
      if (typeof raw === 'string') return `#### ${index + 1}. ${raw}`

      const weakness = asString(item['weakness'] || item['title'] || item['finding'] || `Weakness ${index + 1}`)
      const whyItMatters = asString(item['why_it_matters'] || item['whyItMatters'] || '')
      const severity = asString(item['severity'] || '')
      const recommendedAction = asString(item['recommended_action'] || item['recommendedAction'] || item['action'] || '')

      return [
        `#### ${index + 1}. ${weakness}`,
        severity ? `**Severity:** ${severity}` : '',
        whyItMatters ? `**Why it matters:** ${whyItMatters}` : '',
        recommendedAction ? `**Recommended action:** ${recommendedAction}` : '',
      ]
        .filter(Boolean)
        .join('\n\n')
    })
    .join('\n\n---\n\n')
}

function summaryMarkdown(model: DisplayModel): string {
  const score = model.score_percentage
  const lines = [
    `### Overall result: ${model.overall_result}`,
    score === null || score === undefined || score === '' ? '' : `**Score:** ${String(score)}%`,
    '',
    '#### Executive summary',
    model.executive_summary,
    '',
    '#### Decision-readiness summary',
    model.decision_readiness_summary,
  ]
  return lines.filter((line) => line !== '').join('\n')
}

function sponsorQuestionsMarkdown(items: unknown[]): string {
  if (!items.length) return 'No sponsor or PMO questions returned.'
  return items
    .map((raw, index) => {
      if (typeof raw === 'string') return `#### ${index + 1}. ${raw}`
      const item = (raw as Record<string, unknown>) ?? {}
      const question = asString(item['question'] || item['title'] || `Question ${index + 1}`)
      const whyToAsk = asString(item['why_to_ask'] || item['whyToAsk'] || item['rationale'] || '')
      const priority = asString(item['priority'] || item['severity'] || '')

      return [
        `#### ${index + 1}. ${question}`,
        priority ? `**Priority:** ${priority}` : '',
        whyToAsk ? `**Why to ask:** ${whyToAsk}` : '',
      ]
        .filter(Boolean)
        .join('\n\n')
    })
    .join('\n\n---\n\n')
}

function suggestedRewritesMarkdown(items: unknown[]): string {
  if (!items.length) return 'No suggested rewrites returned.'
  return items
    .map((raw, index) => {
      const item = (raw as Record<string, unknown>) ?? {}
      const target = asString(item['target_section'] || item['targetSection'] || item['section'] || `Rewrite ${index + 1}`)
      const currentIssue = asString(item['current_issue'] || item['currentIssue'] || item['issue'] || '')
      const rewrite = asString(
        item['suggested_rewrite'] || item['suggestedRewrite'] || item['rewrite'] || item['replacement_text'] || '',
      )
      return [
        `#### ${index + 1}. ${target}`,
        currentIssue ? `**Current issue:** ${currentIssue}` : '',
        rewrite ? `**Suggested rewrite:**\n\n${rewrite}` : '',
      ]
        .filter(Boolean)
        .join('\n\n')
    })
    .join('\n\n---\n\n')
}

function qualityFlagsMarkdown(items: unknown[]): string {
  if (!items.length) return 'No quality flags returned.'
  return items
    .map((raw, index) => {
      if (typeof raw === 'string') return `#### ${index + 1}. ${raw}`
      const item = (raw as Record<string, unknown>) ?? {}
      const flag = asString(item['flag'] || item['title'] || item['finding'] || `Quality flag ${index + 1}`)
      const category = asString(item['category'] || '')
      const severity = asString(item['severity'] || item['priority'] || '')
      const explanation = asString(item['explanation'] || item['rationale'] || item['reason'] || '')
      return [
        `#### ${index + 1}. ${flag}`,
        category ? `**Category:** ${category}` : '',
        severity ? `**Severity:** ${severity}` : '',
        explanation ? `**Explanation:** ${explanation}` : '',
      ]
        .filter(Boolean)
        .join('\n\n')
    })
    .join('\n\n---\n\n')
}

function evidenceFindingsMarkdown(items: unknown[]): string {
  if (!items.length) return 'No evidence findings returned.'
  return items
    .map((raw, index) => {
      if (typeof raw === 'string') return `#### ${index + 1}. ${raw}`
      const item = (raw as Record<string, unknown>) ?? {}
      const finding = asString(item['finding'] || item['claim'] || item['title'] || `Evidence finding ${index + 1}`)
      const evidenceBasis = asString(
        item['evidence_basis'] || item['evidenceBasis'] || item['evidence_state'] || item['evidenceState'] || '',
      )
      const reference = asString(
        item['quote_or_reference'] || item['quoteOrReference'] || item['reference'] || item['basis'] || '',
      )
      const implication = asString(
        item['implication'] ||
          item['risk_if_unconfirmed'] ||
          item['riskIfUnconfirmed'] ||
          item['what_to_confirm_next'] ||
          '',
      )
      return [
        `#### ${index + 1}. ${finding}`,
        evidenceBasis ? `**Evidence basis:** ${evidenceBasis}` : '',
        reference ? `**Reference:** ${reference}` : '',
        implication ? `**Implication:** ${implication}` : '',
      ]
        .filter(Boolean)
        .join('\n\n')
    })
    .join('\n\n---\n\n')
}

function startCase(value: string): string {
  if (!value) return ''
  return value
    .replace(/[_-]+/g, ' ')
    .replace(/\s+/g, ' ')
    .trim()
    .split(' ')
    .map((w) => (w ? w[0]!.toUpperCase() + w.slice(1).toLowerCase() : ''))
    .join(' ')
}

type ReviewResultProps = {
  model: DisplayModel
}

export default function ReviewResult({ model }: ReviewResultProps) {
  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-lg">Review result</CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Summary */}
        <section className="space-y-2">
          <h2 className="text-xl font-semibold">Executive Summary</h2>
          <Markdown>{summaryMarkdown(model)}</Markdown>
        </section>

        {/* Material weaknesses */}
        <section className="space-y-2">
          <h2 className="text-xl font-semibold">Material Weaknesses</h2>
          <Markdown>{weaknessesMarkdown(model.decisive_weaknesses)}</Markdown>
        </section>

        {/* Section ratings table */}
        <section className="space-y-2">
          <h2 className="text-xl font-semibold">Section Review Ratings</h2>
          {model.section_scores_table.length === 0 ? (
            <p className="text-sm text-muted-foreground">No rows found.</p>
          ) : (
            <div className="rounded-md border border-border">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="w-[160px]">Rating</TableHead>
                    <TableHead className="w-[200px]">Section</TableHead>
                    <TableHead>Rationale</TableHead>
                    <TableHead className="w-[120px] text-right">Score %</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {model.section_scores_table.map((row, idx) => (
                    <TableRow key={idx}>
                      <TableCell>
                        <span className="inline-flex items-center rounded-full bg-muted px-2 py-0.5 text-xs font-medium text-foreground">
                          {startCase(row.rating) || '—'}
                        </span>
                      </TableCell>
                      <TableCell className="font-medium">{row.section}</TableCell>
                      <TableCell className="text-sm text-muted-foreground">{row.rationale}</TableCell>
                      <TableCell className="text-right tabular-nums">
                        {row.score_percentage === null || row.score_percentage === undefined || row.score_percentage === ''
                          ? '—'
                          : `${String(row.score_percentage)}%`}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </section>

        <section className="space-y-2">
          <h2 className="text-xl font-semibold">Sponsor questions</h2>
          <Markdown>{sponsorQuestionsMarkdown(model.sponsor_questions)}</Markdown>
        </section>

        <section className="space-y-2">
          <h2 className="text-xl font-semibold">Suggested rewrites</h2>
          <Markdown>{suggestedRewritesMarkdown(model.suggested_rewrites)}</Markdown>
        </section>

        <section className="space-y-2">
          <h2 className="text-xl font-semibold">Quality flags</h2>
          <Markdown>{qualityFlagsMarkdown(model.quality_flags)}</Markdown>
        </section>

        <section className="space-y-2">
          <h2 className="text-xl font-semibold">Evidence findings</h2>
          <Markdown>{evidenceFindingsMarkdown(model.evidence_findings)}</Markdown>
        </section>
      </CardContent>
    </Card>
  )
}
