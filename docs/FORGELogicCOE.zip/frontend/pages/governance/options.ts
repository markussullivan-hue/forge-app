// Ported verbatim from /context/linked-classic-app/lib/{materialTypeOptions,aiRelevanceOptions,methodologyLensOptions}.js

export type Option = { label: string; value: string }

export const materialTypeOptions: Option[] = [
  { label: 'Business case', value: 'business_case' },
  { label: 'Project charter', value: 'project_charter' },
  { label: 'PID / initiation document', value: 'pid' },
  { label: 'Programme brief', value: 'programme_brief' },
  { label: 'Steering paper', value: 'steering_paper' },
  { label: 'Gateway pack', value: 'gateway_pack' },
  { label: 'Risk / assurance pack', value: 'risk_assurance_pack' },
  { label: 'Other governance material', value: 'other' },
]

export const aiRelevanceOptions: Option[] = [
  { label: 'AI-relevant', value: 'ai_relevant' },
  { label: 'Possibly AI-relevant', value: 'possibly_ai_relevant' },
  { label: 'Not AI-relevant', value: 'not_ai_relevant' },
]

export const methodologyLensOptions: Option[] = [
  { label: 'General governance review', value: 'general' },
  { label: 'PRINCE2-aligned', value: 'prince2' },
  { label: 'MSP-aligned', value: 'msp' },
  { label: 'PM²-aligned', value: 'pm2' },
  { label: 'PMBOK / PMI-aligned', value: 'pmbok' },
  { label: 'Green Book / Five Case Model', value: 'green_book' },
  { label: 'AgilePM / DSDM-aligned', value: 'agilepm' },
]

export function labelFor(options: Option[], value: string | null | undefined): string {
  if (!value) return ''
  return options.find((o) => o.value === value)?.label ?? value
}
