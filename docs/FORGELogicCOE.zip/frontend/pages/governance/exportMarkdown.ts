// Ports /context/linked-classic-app/lib/{buildGovernanceReviewMarkdownExport,copyGovernanceReviewMarkdown}.js
// to typed helpers.

export type GovernanceReviewDisplay = Record<string, unknown> & {
  overall_result?: unknown
  score_percentage?: unknown
  executive_summary?: unknown
  decision_readiness_summary?: unknown
  decisive_weaknesses?: unknown
  section_scores?: unknown
  section_scores_table?: unknown
  evidence_findings?: unknown
  suggested_rewrites?: unknown
  sponsor_questions?: unknown
  quality_flags?: unknown
  markdown?: unknown
  copy_summary?: unknown
  copy_full_review?: unknown
}

// ---------- shared primitives ----------

function unwrapSingleItemArray(value: unknown): unknown {
  if (Array.isArray(value) && value.length === 1 && value[0] !== null && value[0] !== undefined) {
    return value[0]
  }
  return value
}

function parseMaybeJson(value: unknown, fallback: unknown = null): unknown {
  const unwrapped = unwrapSingleItemArray(value)
  if (unwrapped === null || unwrapped === undefined || unwrapped === '') return fallback
  if (typeof unwrapped === 'object') return unwrapped
  if (typeof unwrapped === 'string') {
    try {
      return JSON.parse(unwrapped)
    } catch {
      return fallback
    }
  }
  return fallback
}

function asArray<T = unknown>(value: unknown): T[] {
  if (Array.isArray(value)) return value as T[]
  if (value === null || value === undefined || value === '') return []
  return [value as T]
}

function firstNonEmptyString(...values: unknown[]): string {
  for (const value of values) {
    const u = unwrapSingleItemArray(value)
    if (typeof u === 'string' && u.trim()) return u.trim()
  }
  return ''
}

function firstDefined(...values: unknown[]): unknown {
  for (const value of values) {
    const u = unwrapSingleItemArray(value)
    if (u !== undefined && u !== null && u !== '') return u
  }
  return null
}

function clean(value: unknown): string {
  if (value === null || value === undefined) return ''
  return String(value).trim()
}

function get(obj: unknown, key: string): unknown {
  if (obj && typeof obj === 'object') return (obj as Record<string, unknown>)[key]
  return undefined
}

// ---------- normalise the workflow result into a display model ----------

export type DisplayModel = {
  overall_result: string
  score_percentage: unknown
  executive_summary: string
  decision_readiness_summary: string
  decisive_weaknesses: unknown[]
  section_scores: unknown[]
  section_scores_table: Array<{
    section: string
    score_percentage: unknown
    rating: string
    rationale: string
  }>
  evidence_findings: unknown[]
  suggested_rewrites: unknown[]
  sponsor_questions: unknown[]
  quality_flags: unknown[]
  markdown: string
  copy_summary: string
  copy_full_review: string
  // pass-through extras
  [extra: string]: unknown
}

function formatListForMarkdown(items: unknown, formatter: (item: any, index: number) => string): string {
  const rows = asArray(items).filter(Boolean)
  if (!rows.length) return ''
  return rows.map((item, i) => formatter(item, i)).filter(Boolean).join('\n\n')
}

export function normaliseReviewResult(source: unknown): DisplayModel {
  const unwrapped = unwrapSingleItemArray(source)
  const result = (parseMaybeJson(unwrapped, {}) as Record<string, unknown>) || {}

  const overallResult = firstNonEmptyString(
    result['overall_result'],
    result['overallResult'],
    result['rating'],
    result['readiness'],
    result['readiness_state'],
    'Not assessed',
  )

  const scorePercentage = firstDefined(
    result['score_percentage'],
    result['scorePercentage'],
    result['score'],
    result['overall_score'],
  )

  const executiveSummary = firstNonEmptyString(
    result['executive_summary'],
    result['executiveSummary'],
    result['summary'],
    'No executive summary returned.',
  )

  const decisionReadinessSummary = firstNonEmptyString(
    result['decision_readiness_summary'],
    result['decisionReadinessSummary'],
    result['readiness_summary'],
    'No decision-readiness summary returned.',
  )

  const decisiveWeaknesses = asArray(
    firstDefined(result['decisive_weaknesses'], result['decisiveWeaknesses'], result['weaknesses'], []),
  )

  const sectionScores = asArray(
    firstDefined(
      result['section_scores'],
      result['sectionScores'],
      result['section_scores_table'],
      result['sectionScoresTable'],
      result['sections'],
      [],
    ),
  )

  const evidenceFindings = asArray(
    firstDefined(result['evidence_findings'], result['evidenceFindings'], result['findings'], []),
  )

  const suggestedRewrites = asArray(
    firstDefined(result['suggested_rewrites'], result['suggestedRewrites'], result['rewrites'], []),
  )

  const sponsorQuestions = asArray(
    firstDefined(result['sponsor_questions'], result['sponsorQuestions'], result['questions'], []),
  )

  const qualityFlags = asArray(
    firstDefined(result['quality_flags'], result['qualityFlags'], result['flags'], []),
  )

  const sectionScoresTable = sectionScores.map((raw, index) => {
    const item = (raw as Record<string, unknown>) ?? {}
    return {
      section:
        (item['section'] as string) ||
        (item['name'] as string) ||
        (item['title'] as string) ||
        `Section ${index + 1}`,
      score_percentage:
        item['score_percentage'] ?? item['scorePercentage'] ?? item['score'] ?? null,
      rating:
        (item['rating'] as string) ||
        (item['readiness'] as string) ||
        (item['result'] as string) ||
        '',
      rationale:
        (item['rationale'] as string) ||
        (item['reason'] as string) ||
        (item['commentary'] as string) ||
        '',
    }
  })

  const generatedMarkdown = [
    '# Governance review',
    '',
    '## Overall result',
    '',
    `**Result:** ${overallResult}`,
    scorePercentage === null || scorePercentage === undefined || scorePercentage === ''
      ? ''
      : `**Score:** ${String(scorePercentage)}%`,
    '',
    '## Executive summary',
    '',
    executiveSummary,
    '',
    '## Decision-readiness summary',
    '',
    decisionReadinessSummary,
    '',
    decisiveWeaknesses.length ? '## Decisive weaknesses' : '',
    '',
    formatListForMarkdown(decisiveWeaknesses, (item, index) => {
      if (typeof item === 'string') return `${index + 1}. ${item}`
      return [
        `${index + 1}. ${item.weakness || item.title || item.finding || 'Weakness'}`,
        item.severity ? `   - Severity: ${item.severity}` : '',
        item.why_it_matters || item.whyItMatters
          ? `   - Why it matters: ${item.why_it_matters || item.whyItMatters}`
          : '',
        item.recommended_action || item.recommendedAction
          ? `   - Recommended action: ${item.recommended_action || item.recommendedAction}`
          : '',
      ]
        .filter(Boolean)
        .join('\n')
    }),
    '',
    sectionScoresTable.length ? '## Section scores' : '',
    '',
    formatListForMarkdown(sectionScoresTable, (item, index) => {
      return [
        `${index + 1}. ${item.section}`,
        item.score_percentage === null || item.score_percentage === undefined || item.score_percentage === ''
          ? ''
          : `   - Score: ${String(item.score_percentage)}%`,
        item.rating ? `   - Rating: ${item.rating}` : '',
        item.rationale ? `   - Rationale: ${item.rationale}` : '',
      ]
        .filter(Boolean)
        .join('\n')
    }),
    '',
    evidenceFindings.length ? '## Evidence findings' : '',
    '',
    formatListForMarkdown(evidenceFindings, (item, index) => {
      if (typeof item === 'string') return `${index + 1}. ${item}`
      return [
        `${index + 1}. ${item.finding || item.title || 'Finding'}`,
        item.evidence_basis || item.evidenceBasis
          ? `   - Evidence basis: ${item.evidence_basis || item.evidenceBasis}`
          : '',
        item.quote_or_reference || item.quoteOrReference
          ? `   - Reference: ${item.quote_or_reference || item.quoteOrReference}`
          : '',
        item.implication ? `   - Implication: ${item.implication}` : '',
      ]
        .filter(Boolean)
        .join('\n')
    }),
    '',
    sponsorQuestions.length ? '## Sponsor questions' : '',
    '',
    formatListForMarkdown(sponsorQuestions, (item, index) => {
      if (typeof item === 'string') return `${index + 1}. ${item}`
      return [
        `${index + 1}. ${item.question || item.title || 'Question'}`,
        item.priority ? `   - Priority: ${item.priority}` : '',
        item.why_to_ask || item.whyToAsk || item.rationale
          ? `   - Why to ask: ${item.why_to_ask || item.whyToAsk || item.rationale}`
          : '',
      ]
        .filter(Boolean)
        .join('\n')
    }),
    '',
    suggestedRewrites.length ? '## Suggested rewrites' : '',
    '',
    formatListForMarkdown(suggestedRewrites, (item, index) => {
      if (typeof item === 'string') return `${index + 1}. ${item}`
      return [
        `${index + 1}. ${item.target_section || item.targetSection || item.section || 'Target section'}`,
        item.current_issue || item.currentIssue
          ? `   - Current issue: ${item.current_issue || item.currentIssue}`
          : '',
        item.suggested_rewrite || item.suggestedRewrite
          ? `   - Suggested rewrite: ${item.suggested_rewrite || item.suggestedRewrite}`
          : '',
      ]
        .filter(Boolean)
        .join('\n')
    }),
    '',
    qualityFlags.length ? '## Quality flags' : '',
    '',
    formatListForMarkdown(qualityFlags, (item, index) => {
      if (typeof item === 'string') return `${index + 1}. ${item}`
      return [
        `${index + 1}. ${item.flag || item.title || item.finding || 'Quality flag'}`,
        item.category ? `   - Category: ${item.category}` : '',
        item.severity || item.priority ? `   - Severity: ${item.severity || item.priority}` : '',
        item.explanation || item.rationale || item.reason
          ? `   - Explanation: ${item.explanation || item.rationale || item.reason}`
          : '',
      ]
        .filter(Boolean)
        .join('\n')
    }),
  ]
    .filter((line) => line !== '')
    .join('\n')

  const markdown = firstNonEmptyString(
    result['markdown'],
    result['markdown_review'],
    result['full_markdown'],
    generatedMarkdown,
  )

  const copySummary = firstNonEmptyString(
    result['copy_summary'],
    [
      'FORGE Governance Pack Review',
      '',
      `Overall result: ${overallResult}`,
      scorePercentage === null || scorePercentage === undefined || scorePercentage === ''
        ? ''
        : `Score: ${String(scorePercentage)}%`,
      '',
      'Executive summary:',
      executiveSummary,
      '',
      'Decision-readiness summary:',
      decisionReadinessSummary,
    ]
      .filter((line) => line !== '')
      .join('\n'),
  )

  const copyFullReview = firstNonEmptyString(result['copy_full_review'], markdown)

  return {
    ...result,
    overall_result: overallResult,
    score_percentage: scorePercentage,
    executive_summary: executiveSummary,
    decision_readiness_summary: decisionReadinessSummary,
    decisive_weaknesses: decisiveWeaknesses,
    section_scores: sectionScores,
    section_scores_table: sectionScoresTable,
    evidence_findings: evidenceFindings,
    suggested_rewrites: suggestedRewrites,
    sponsor_questions: sponsorQuestions,
    quality_flags: qualityFlags,
    markdown,
    copy_summary: copySummary,
    copy_full_review: copyFullReview,
  }
}

// ---------- download .md (buildGovernanceReviewMarkdownExport) ----------

export type ExportPayload = {
  fileName: string
  markdown: string
}

export function buildGovernanceReviewMarkdownExport(display: GovernanceReviewDisplay | null): ExportPayload {
  const result = (display ?? {}) as Record<string, unknown>

  const overallResult = clean(result['overall_result'] || result['overallResult'] || 'Not stated')
  const scorePercentage = clean(result['score_percentage'] ?? result['scorePercentage'] ?? '')
  const executiveSummary = clean(result['executive_summary'] || result['executiveSummary'] || '')
  const decisionReadinessSummary = clean(
    result['decision_readiness_summary'] || result['decisionReadinessSummary'] || '',
  )

  const decisiveWeaknesses = asArray(result['decisive_weaknesses'] || result['decisiveWeaknesses'] || [])
  const sectionScores = asArray(result['section_scores'] || result['sectionScores'] || [])
  const evidenceFindings = asArray(
    result['evidence_findings'] || result['evidenceFindings'] || result['evidence'] || [],
  )
  const suggestedRewrites = asArray(result['suggested_rewrites'] || result['suggestedRewrites'] || [])
  const sponsorQuestions = asArray(result['sponsor_questions'] || result['sponsorQuestions'] || [])
  const qualityFlags = asArray(result['quality_flags'] || result['qualityFlags'] || [])

  const lines: string[] = []

  lines.push('# FORGE Governance Pack Review', '')

  lines.push('## Overall result', '')
  lines.push(`**Result:** ${overallResult}`)
  if (scorePercentage !== '') lines.push(`**Score:** ${scorePercentage}%`)
  lines.push('')

  if (executiveSummary) {
    lines.push('## Executive summary', '', executiveSummary, '')
  }
  if (decisionReadinessSummary) {
    lines.push('## Decision-readiness summary', '', decisionReadinessSummary, '')
  }

  if (decisiveWeaknesses.length > 0) {
    lines.push('## Decisive weaknesses', '')
    decisiveWeaknesses.forEach((item, index) => {
      const weakness = clean(get(item, 'weakness') || get(item, 'finding') || get(item, 'area') || `Weakness ${index + 1}`)
      const whyItMatters = clean(get(item, 'why_it_matters') || get(item, 'whyItMatters') || '')
      const severity = clean(get(item, 'severity') || '')
      const recommendedAction = clean(get(item, 'recommended_action') || get(item, 'recommendedAction') || '')

      lines.push(`### ${index + 1}. ${weakness}`, '')
      if (severity) lines.push(`**Severity:** ${severity}`, '')
      if (whyItMatters) lines.push(`**Why it matters:** ${whyItMatters}`, '')
      if (recommendedAction) lines.push(`**Recommended action:** ${recommendedAction}`, '')
    })
  }

  if (sectionScores.length > 0) {
    lines.push('## Section-level review', '')
    sectionScores.forEach((item, index) => {
      const section = clean(get(item, 'section') || get(item, 'area') || `Section ${index + 1}`)
      const rating = clean(
        get(item, 'rating') || get(item, 'score') || get(item, 'evidence_state') || get(item, 'evidenceState') || '',
      )
      const score = clean(get(item, 'score_percentage') ?? get(item, 'scorePercentage') ?? '')
      const rationale = clean(get(item, 'rationale') || get(item, 'finding') || '')
      const recommendedAction = clean(get(item, 'recommended_action') || get(item, 'recommendedAction') || '')

      lines.push(`### ${section}`, '')
      if (rating) lines.push(`**Rating:** ${rating}`)
      if (score !== '') lines.push(`**Score:** ${score}%`)
      if (rating || score !== '') lines.push('')
      if (rationale) lines.push(rationale, '')
      if (recommendedAction) lines.push(`**Recommended action:** ${recommendedAction}`, '')
    })
  }

  if (evidenceFindings.length > 0) {
    lines.push('## Evidence findings', '')
    evidenceFindings.forEach((item, index) => {
      const finding = clean(
        get(item, 'finding') || get(item, 'claim') || get(item, 'summary') || get(item, 'observation') || `Evidence finding ${index + 1}`,
      )
      const evidenceBasis = clean(
        get(item, 'evidence_basis') || get(item, 'evidenceBasis') || get(item, 'evidence_state') || get(item, 'evidenceState') || get(item, 'basis') || 'Not stated',
      )
      const quoteOrReference = clean(
        get(item, 'quote_or_reference') || get(item, 'quoteOrReference') || get(item, 'reference') || get(item, 'quote') || '',
      )
      const implication = clean(
        get(item, 'implication') || get(item, 'impact') || get(item, 'risk_if_unconfirmed') || get(item, 'riskIfUnconfirmed') || '',
      )
      const whatToConfirmNext = clean(get(item, 'what_to_confirm_next') || get(item, 'whatToConfirmNext') || '')

      lines.push(`### ${index + 1}. ${finding}`, '')
      lines.push(`**Evidence basis:** ${evidenceBasis}`, '')
      if (quoteOrReference) lines.push(`**Quote / reference:** ${quoteOrReference}`, '')
      if (implication) lines.push(`**Implication:** ${implication}`, '')
      if (whatToConfirmNext) lines.push(`**What to confirm next:** ${whatToConfirmNext}`, '')
    })
  }

  if (suggestedRewrites.length > 0) {
    lines.push('## Suggested rewrites', '')
    suggestedRewrites.forEach((item, index) => {
      const targetSection = clean(
        get(item, 'target_section') || get(item, 'targetSection') || get(item, 'section') || `Suggested rewrite ${index + 1}`,
      )
      const currentIssue = clean(get(item, 'current_issue') || get(item, 'currentIssue') || '')
      const suggestedRewrite = clean(
        get(item, 'suggested_rewrite') || get(item, 'suggestedRewrite') || get(item, 'replacement_text') || get(item, 'replacementText') || '',
      )

      lines.push(`### ${targetSection}`, '')
      if (currentIssue) lines.push(`**Current issue:** ${currentIssue}`, '')
      if (suggestedRewrite) lines.push('**Suggested rewrite:**', '', suggestedRewrite, '')
    })
  }

  if (sponsorQuestions.length > 0) {
    lines.push('## Sponsor / PMO questions', '')
    sponsorQuestions.forEach((item, index) => {
      if (typeof item === 'string') {
        lines.push(`${index + 1}. ${clean(item)}`)
        return
      }
      const question = clean(get(item, 'question') || `Question ${index + 1}`)
      const whyToAsk = clean(get(item, 'why_to_ask') || get(item, 'whyToAsk') || '')
      const priority = clean(get(item, 'priority') || '')

      lines.push(`${index + 1}. ${question}`)
      if (priority || whyToAsk) {
        lines.push('')
        if (priority) lines.push(`   **Priority:** ${priority}`)
        if (whyToAsk) lines.push(`   **Why to ask:** ${whyToAsk}`)
        lines.push('')
      }
    })
    lines.push('')
  }

  if (qualityFlags.length > 0) {
    lines.push('## Quality flags', '')
    qualityFlags.forEach((item, index) => {
      if (typeof item === 'string') {
        lines.push(`${index + 1}. ${clean(item)}`)
        return
      }
      const flag = clean(get(item, 'flag') || get(item, 'finding') || `Quality flag ${index + 1}`)
      const category = clean(get(item, 'category') || '')
      const severity = clean(get(item, 'severity') || '')
      const explanation = clean(get(item, 'explanation') || get(item, 'rationale') || '')

      lines.push(`### ${index + 1}. ${flag}`, '')
      if (category) lines.push(`**Category:** ${category}`)
      if (severity) lines.push(`**Severity:** ${severity}`)
      if (category || severity) lines.push('')
      if (explanation) lines.push(explanation, '')
    })
  }

  lines.push('---', '')
  lines.push('Generated by FORGE Governance Pack Review.')
  lines.push('Source text is not included in this export.')

  const markdown = lines.join('\n').replace(/\n{4,}/g, '\n\n\n').trim()

  const now = new Date()
  const pad = (v: number) => String(v).padStart(2, '0')
  const fileStamp = [now.getFullYear(), pad(now.getMonth() + 1), pad(now.getDate())].join('-')

  return {
    fileName: `forge-governance-pack-review-${fileStamp}.md`,
    markdown,
  }
}

// Trigger a .md download from the browser.
export function downloadMarkdown(payload: ExportPayload): void {
  const blob = new Blob([payload.markdown], { type: 'text/markdown;charset=utf-8' })
  const url = URL.createObjectURL(blob)
  const a = document.createElement('a')
  a.href = url
  a.download = payload.fileName
  document.body.appendChild(a)
  a.click()
  document.body.removeChild(a)
  // Defer URL revocation so Safari/Firefox actually fire the download.
  setTimeout(() => URL.revokeObjectURL(url), 1000)
}

// ---------- copy review markdown (buyer-friendly) ----------

function text(value: unknown, fallback = ''): string {
  if (value == null) return fallback
  if (typeof value === 'string') return value.trim()
  if (typeof value === 'number') return String(value)
  if (typeof value === 'boolean') return String(value)
  return fallback
}

function cleanSummary(value: unknown): string {
  return text(value)
    .replace(/^FORGE Governance Pack Review\s*/i, '')
    .replace(/^Overall result:.*$/gim, '')
    .replace(/^Score:.*$/gim, '')
    .replace(/^Executive summary:\s*/gim, '')
    .replace(/^Decision-readiness summary:\s*/gim, '\n\nDecision-readiness: ')
    .replace(/\n{3,}/g, '\n\n')
    .trim()
}

function asLinesArray(...values: unknown[]): unknown[] {
  for (const value of values) {
    if (Array.isArray(value)) return (value as unknown[]).filter(Boolean)
    if (typeof value === 'string' && value.trim()) {
      return value
        .split('\n')
        .map((line) => line.trim())
        .filter(Boolean)
    }
  }
  return []
}

function sentence(...parts: unknown[]): string {
  return parts
    .map((p) => text(p))
    .filter(Boolean)
    .join(' ')
    .replace(/\s+/g, ' ')
    .trim()
}

function formatNumberedList(
  items: unknown[],
  formatter: (item: any) => string,
  emptyText: string,
): string {
  if (!items.length) return emptyText
  return items
    .map((item, index) => {
      if (typeof item === 'string') return `${index + 1}. ${item}`
      return `${index + 1}. ${formatter(item)}`
    })
    .filter((line) => line.replace(/^\d+\.\s*/, '').trim())
    .join('\n')
}

export function buildGovernanceReviewCopyMarkdown(source: GovernanceReviewDisplay | null): string {
  const src = (source ?? {}) as Record<string, unknown>

  const overallResult =
    text(
      get(src, 'overall_result') ||
        get(get(src, 'result'), 'overall_result') ||
        get(get(src, 'display_model'), 'overall_result'),
    ) || 'Not assessed'

  const scorePercentageRaw =
    src['score_percentage'] ??
    get(get(src, 'result'), 'score_percentage') ??
    get(get(src, 'display_model'), 'score_percentage') ??
    ''
  const scorePercentage = text(scorePercentageRaw)

  const summary = cleanSummary(src['summary'] || src['review_summary'] || src['copy_summary'] || '')

  const evidenceFindings = asLinesArray(src['evidence_findings'], src['evidenceFindings'])
  const sectionScores = asLinesArray(src['section_scores'], src['sections'], src['sectionScores'])
  const sponsorQuestions = asLinesArray(src['sponsor_questions'], src['sponsorQuestions'])
  const suggestedRewrites = asLinesArray(src['suggested_rewrites'], src['suggestedRewrites'])
  const qualityFlags = asLinesArray(src['quality_flags'], src['qualityFlags'])
  const weaknesses = asLinesArray(src['weaknesses'], src['key_weaknesses'], src['review_weaknesses'])

  const formatEvidence = (items: unknown[]) =>
    formatNumberedList(
      items,
      (item) => {
        const finding = text(item.finding || item.title || 'Finding')
        const implication = text(item.implication)
        const basis = text(item.evidence_basis || item.basis)
        const reference = text(item.quote_or_reference || item.reference)
        return sentence(
          `${finding}.`,
          implication,
          basis ? `Evidence basis: ${basis}.` : '',
          reference ? `Reference: "${reference}"` : '',
        )
      },
      'No specific evidence findings were provided.',
    )

  const formatQuestions = (items: unknown[]) =>
    formatNumberedList(
      items,
      (item) => {
        const priority = text(item.priority)
        const question = text(item.question)
        const why = text(item.why_to_ask || item.why)
        return sentence(priority ? `[${priority}]` : '', question, why ? `Why this matters: ${why}` : '')
      },
      'No sponsor questions were provided.',
    )

  const formatRewrites = (items: unknown[]) =>
    formatNumberedList(
      items,
      (item) => {
        const section = text(item.target_section || item.section || 'Suggested improvement')
        const issue = text(item.current_issue || item.issue)
        const rewrite = text(item.suggested_rewrite || item.rewrite)
        return sentence(`${section}.`, issue ? `Issue: ${issue}` : '', rewrite ? `Suggested improvement: ${rewrite}` : '')
      },
      'No suggested improvements were provided.',
    )

  const formatFlags = (items: unknown[]) =>
    formatNumberedList(
      items,
      (item) => {
        const severity = text(item.severity)
        const category = text(item.category)
        const flag = text(item.flag || item.title)
        const explanation = text(item.explanation || item.reason)
        const label = [severity, category].filter(Boolean).join(' / ')
        return sentence(label ? `[${label}]` : '', flag, explanation)
      },
      'No quality flags were raised.',
    )

  const formatSectionScores = (items: unknown[]) => {
    if (!items.length) return 'No section scores were available.'
    return items
      .map((row) => {
        const r = row as Record<string, unknown>
        const section = text(r['section'] || r['name'] || r['area'] || 'Section')
        const result = text(r['result'] || r['rating'] || r['assessment'] || 'Not assessed')
        const score = text(r['score'] || r['score_percentage'] || r['percentage'] || '')
        return score ? `${section}: ${result} (${score}/100)` : `${section}: ${result}`
      })
      .join('\n')
  }

  const lines = [
    'FORGE Logic™ Governance Review',
    '',
    `Overall result: ${overallResult}`,
    scorePercentage !== '' ? `Score: ${scorePercentage}%` : '',
    '',
    'Summary',
    '',
    summary || 'No summary was provided.',
    '',
    'What the review found',
    '',
    formatEvidence(evidenceFindings),
    '',
    'Section scores',
    '',
    formatSectionScores(sectionScores),
    '',
    'Questions to ask before approving',
    '',
    formatQuestions(sponsorQuestions),
    '',
    'Suggested improvements',
    '',
    formatRewrites(suggestedRewrites),
    '',
    'Quality flags',
    '',
    formatFlags(qualityFlags),
    weaknesses.length ? '' : null,
    weaknesses.length ? 'Additional weaknesses' : null,
    weaknesses.length ? '' : null,
    weaknesses.length ? weaknesses.map((item, index) => `${index + 1}. ${text(item)}`).join('\n') : null,
    '',
    'Generated by FORGE Logic™ Governance Review',
    `Generated on: ${new Date().toLocaleString()}`,
  ]
    .filter((line) => line !== null && line !== undefined)
    .join('\n')
    .replace(/\n{3,}/g, '\n\n')
    .trim()

  return lines
}

export async function copyMarkdownToClipboard(textValue: string): Promise<boolean> {
  if (!textValue.trim()) return false
  try {
    await navigator.clipboard.writeText(textValue)
    return true
  } catch {
    return false
  }
}
