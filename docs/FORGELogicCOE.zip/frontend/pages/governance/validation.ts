// Ported verbatim from /context/linked-classic-app/lib/reviewInputValidation.js

export type ReviewValidationInput = {
  materialType: string | null
  aiRelevance: string | null
  methodologyLens: string | null
  governanceText: string | null
}

export type ReviewValidationResult = {
  canRun: boolean
  materialType: string | null
  aiRelevance: string | null
  methodologyLens: string | null
  characterCount: number
  wordCount: number
  errors: string[]
  warnings: string[]
  inputPreview: string
}

export function reviewInputValidation(input: ReviewValidationInput): ReviewValidationResult {
  const materialType = input.materialType ?? null
  const aiRelevance = input.aiRelevance ?? null
  const methodologyLens = input.methodologyLens ?? null
  const pastedText = String(input.governanceText ?? '').trim()

  const characterCount = pastedText.length
  const wordCount = pastedText ? pastedText.split(/\s+/).filter(Boolean).length : 0

  const errors: string[] = []
  const warnings: string[] = []

  if (!materialType) {
    errors.push('Select the material type.')
  }
  if (!aiRelevance) {
    errors.push('Select the AI relevance.')
  }
  if (!methodologyLens) {
    errors.push('Select the methodology or governance lens.')
  }
  if (!pastedText) {
    errors.push('Paste the governance text to review.')
  }
  if (pastedText && characterCount < 750) {
    errors.push(
      'Paste a fuller governance extract. The review needs at least 750 characters to be meaningful.',
    )
  }
  if (characterCount > 120000) {
    errors.push(
      'The pasted text is too long for V2a.0. Keep it below 120,000 characters for this first version.',
    )
  }
  if (wordCount > 18000) {
    warnings.push(
      'This is a large paste-in review. The workflow should summarise and challenge it, but response time may be longer.',
    )
  }

  return {
    canRun: errors.length === 0,
    materialType,
    aiRelevance,
    methodologyLens,
    characterCount,
    wordCount,
    errors,
    warnings,
    inputPreview: pastedText.slice(0, 500),
  }
}
