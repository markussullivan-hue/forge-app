// Document upload card for the Governance Review page.
//
// Lets a user pick (or drag-and-drop) a .pdf / .docx / .txt / .md file. The
// file is parsed to plain text entirely in the browser (see
// /frontend/utils/extractDocumentText.ts) and the result is handed back to
// the parent via `onExtracted`. The parent owns the textarea state — this
// component is otherwise stateless aside from the in-progress + pending-file
// flags it needs locally.

import { useRef, useState, type ChangeEvent, type DragEvent } from 'react'
import { toast } from 'sonner'
import { FileText, Loader2, ShieldCheck, Upload, X } from 'lucide-react'
import { Button } from '../../lib/shadcn/button'
import { Card, CardContent } from '../../lib/shadcn/card'
import { Label } from '../../lib/shadcn/label'
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '../../lib/shadcn/alert-dialog'
import {
  extractDocumentText,
  formatBytes,
  getExtension,
  isSupportedExtension,
  MAX_UPLOAD_BYTES,
} from '../../utils/extractDocumentText'

export type UploadedDocumentMeta = {
  fileName: string
  fileSize: number
  characterCount: number
  wordCount: number
}

type Props = {
  /** True when the parent textarea already has content; we'll warn before replacing. */
  hasExistingText: boolean
  /** Currently-displayed uploaded file metadata, or null if none. */
  uploadedDocument: UploadedDocumentMeta | null
  /** Called when extraction succeeds. The parent should replace its textarea state. */
  onExtracted: (text: string, meta: UploadedDocumentMeta) => void
  /** Called when the user clicks "Remove" on the uploaded-file chip. */
  onClear: () => void
  /** Disables the input (e.g. while a review is running). */
  disabled?: boolean
}

const ACCEPT = '.pdf,.docx,.txt,.md'

export default function DocumentUpload({
  hasExistingText,
  uploadedDocument,
  onExtracted,
  onClear,
  disabled,
}: Props) {
  const inputRef = useRef<HTMLInputElement | null>(null)
  const [isExtracting, setIsExtracting] = useState(false)
  const [isDragging, setIsDragging] = useState(false)
  const [pendingFile, setPendingFile] = useState<File | null>(null)

  const openPicker = () => {
    if (disabled || isExtracting) return
    inputRef.current?.click()
  }

  // Front-door validation so we can give a tidy toast before kicking off
  // (extraction would throw the same error, but this catches it before we
  // show the confirm dialog and avoids an awkward two-step UX).
  const preflight = (file: File): string | null => {
    const ext = getExtension(file.name)
    if (!isSupportedExtension(ext)) {
      return `Unsupported file type ".${ext || 'unknown'}". Upload .pdf, .docx, .txt or .md.`
    }
    if (file.size > MAX_UPLOAD_BYTES) {
      return `File is ${formatBytes(file.size)}; the limit is ${formatBytes(MAX_UPLOAD_BYTES)}.`
    }
    return null
  }

  const startExtraction = async (file: File) => {
    setIsExtracting(true)
    try {
      const result = await extractDocumentText(file)
      onExtracted(result.text, {
        fileName: file.name,
        fileSize: file.size,
        characterCount: result.characterCount,
        wordCount: result.wordCount,
      })
      toast.success('Document extracted', {
        description: `${file.name} — ${result.wordCount.toLocaleString()} words extracted into the text box below. The original file has been discarded.`,
      })
    } catch (err) {
      const message = err instanceof Error ? err.message : String(err)
      toast.error('Could not read document', { description: message })
    } finally {
      setIsExtracting(false)
      // Reset the underlying input so the same file name can be re-uploaded later.
      if (inputRef.current) inputRef.current.value = ''
    }
  }

  const handleFileChosen = (file: File) => {
    const err = preflight(file)
    if (err) {
      toast.error('Upload rejected', { description: err })
      if (inputRef.current) inputRef.current.value = ''
      return
    }
    if (hasExistingText) {
      // Defer extraction until the user confirms replacement.
      setPendingFile(file)
      return
    }
    void startExtraction(file)
  }

  const handleInputChange = (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return
    handleFileChosen(file)
  }

  const handleDrop = (e: DragEvent<HTMLDivElement>) => {
    e.preventDefault()
    setIsDragging(false)
    if (disabled || isExtracting) return
    const file = e.dataTransfer.files?.[0]
    if (!file) return
    handleFileChosen(file)
  }

  const handleDragOver = (e: DragEvent<HTMLDivElement>) => {
    e.preventDefault()
    if (disabled || isExtracting) return
    setIsDragging(true)
  }

  const handleDragLeave = () => setIsDragging(false)

  const confirmReplace = async () => {
    const file = pendingFile
    setPendingFile(null)
    if (file) await startExtraction(file)
  }
  const cancelReplace = () => {
    setPendingFile(null)
    if (inputRef.current) inputRef.current.value = ''
  }

  return (
    <Card>
      <CardContent className="pt-6 space-y-4">
        <div className="space-y-1.5">
          <Label className="text-base font-semibold">Upload a document (optional)</Label>
          <p className="text-xs text-muted-foreground">
            Accepted: <code className="font-mono">.pdf</code>,{' '}
            <code className="font-mono">.docx</code>, <code className="font-mono">.txt</code>,{' '}
            <code className="font-mono">.md</code> · max {formatBytes(MAX_UPLOAD_BYTES)}.
          </p>
        </div>

        {/* Privacy notice */}
        <div className="flex gap-3 rounded-md border border-border bg-muted/40 p-3 text-xs text-muted-foreground">
          <ShieldCheck className="h-4 w-4 shrink-0 mt-0.5 text-primary" />
          <div className="space-y-1 leading-relaxed">
            <p>
              <span className="font-medium text-foreground">Your document is never stored.</span>{' '}
              Text is extracted in your browser and discarded as soon as you clear the form or
              leave the page.
            </p>
            <p>
              The governance review report is generated on demand. When you download it, it is also
              discarded from server memory.
            </p>
          </div>
        </div>

        {uploadedDocument ? (
          // Uploaded-file chip
          <div className="flex items-center justify-between gap-3 rounded-md border border-border bg-card px-3 py-2">
            <div className="flex items-center gap-3 min-w-0">
              <FileText className="h-5 w-5 shrink-0 text-primary" />
              <div className="min-w-0">
                <p className="truncate text-sm font-medium">{uploadedDocument.fileName}</p>
                <p className="text-xs text-muted-foreground">
                  {formatBytes(uploadedDocument.fileSize)} ·{' '}
                  {uploadedDocument.wordCount.toLocaleString()} words ·{' '}
                  {uploadedDocument.characterCount.toLocaleString()} chars
                </p>
              </div>
            </div>
            <Button
              type="button"
              variant="ghost"
              size="sm"
              onClick={onClear}
              disabled={disabled}
              aria-label="Remove uploaded document"
            >
              <X className="h-4 w-4 mr-1" />
              Remove
            </Button>
          </div>
        ) : (
          // Drop zone
          <div
            onClick={openPicker}
            onDragOver={handleDragOver}
            onDragLeave={handleDragLeave}
            onDrop={handleDrop}
            role="button"
            tabIndex={0}
            onKeyDown={(e) => {
              if (e.key === 'Enter' || e.key === ' ') {
                e.preventDefault()
                openPicker()
              }
            }}
            aria-disabled={disabled || isExtracting}
            className={[
              'flex flex-col items-center justify-center gap-2 rounded-md border-2 border-dashed px-6 py-8 text-center transition-colors',
              'cursor-pointer hover:border-primary/60 hover:bg-muted/30',
              isDragging ? 'border-primary bg-primary/5' : 'border-border',
              disabled || isExtracting ? 'pointer-events-none opacity-60' : '',
            ].join(' ')}
          >
            {isExtracting ? (
              <>
                <Loader2 className="h-6 w-6 animate-spin text-primary" />
                <p className="text-sm text-muted-foreground">Extracting text…</p>
              </>
            ) : (
              <>
                <Upload className="h-6 w-6 text-muted-foreground" />
                <p className="text-sm">
                  <span className="font-medium text-foreground">Click to upload</span>{' '}
                  <span className="text-muted-foreground">or drag and drop</span>
                </p>
                <p className="text-xs text-muted-foreground">
                  PDF, DOCX, TXT or MD — up to {formatBytes(MAX_UPLOAD_BYTES)}
                </p>
              </>
            )}
          </div>
        )}

        {/* Replace warning — visible whenever textarea has content & nothing is uploaded yet */}
        {hasExistingText && !uploadedDocument ? (
          <p className="text-xs text-amber-600 dark:text-amber-400">
            Uploading a document will replace the text currently pasted below.
          </p>
        ) : null}

        <input
          ref={inputRef}
          type="file"
          accept={ACCEPT}
          className="hidden"
          onChange={handleInputChange}
          disabled={disabled || isExtracting}
        />
      </CardContent>

      <AlertDialog open={pendingFile !== null} onOpenChange={(o) => (!o ? cancelReplace() : null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Replace pasted text?</AlertDialogTitle>
            <AlertDialogDescription>
              You already have text pasted in the governance text box. Uploading{' '}
              <span className="font-medium">{pendingFile?.name}</span> will replace it with the
              extracted text from this document. This can&apos;t be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel onClick={cancelReplace}>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={confirmReplace}>Replace text</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </Card>
  )
}
