import { useEffect, useMemo } from 'react'
import { useNavigate } from 'react-router-dom'
import { Plus, Sparkles } from 'lucide-react'
import { toast } from 'sonner'
import type { ColumnDef } from '@tanstack/react-table'
import { Button } from '../lib/shadcn/button'
import { useAppState } from '../utils/appState'
import {
  useGetContinueWorkingProjects,
  useGetDashboardKpis,
  useGetDecisionsNeeded,
  useGetRecentGenerationRuns,
  useGetRisksAssuranceItems,
} from '../hooks/backend/dashboard'
import KpiCard from './ui/KpiCard'
import DataTable from './ui/DataTable'

// ---- Types matching backend return shapes ----------------------------------

type DashboardKpis = {
  active_projects: number
  projects_requiring_decision: number
  artefacts_generated: number
  open_risks: number
  runs_completed: number
  items_needing_review: number
}

type RecentGenerationRunRow = {
  run_id: string
  project_id: string | null
  project_name: string
  run_status: string | null
  current_stage: string | null
  completed_at: string | null
  action_label: string
}

type ContinueWorkingProjectRow = {
  project_id: string
  project_name: string
  lifecycle_stage: string | null
  status: string | null
  last_updated_at: string | null
  action_label: string
}

type RiskAssuranceRow = {
  risk_id: string
  project_name: string
  risk_or_assurance_item: string
  severity: string
  owner: string
  status: string
}

type DecisionNeededRow = {
  project_id: string
  project_name: string
  decision_needed: string
  priority: string
  due_date: string | null
}

// ---- Helpers ----------------------------------------------------------------

const DATE_FORMAT = new Intl.DateTimeFormat(undefined, {
  year: 'numeric',
  month: 'short',
  day: '2-digit',
  hour: '2-digit',
  minute: '2-digit',
})

function formatDateTime(value: string | null | undefined): string {
  if (!value) return '—'
  const d = new Date(value)
  if (Number.isNaN(d.getTime())) return '—'
  return DATE_FORMAT.format(d)
}

// ---- Page -------------------------------------------------------------------

export default function DashboardPage() {
  const navigate = useNavigate()
  const { currentOrgId, selectedProjectId, setAppState } = useAppState()

  const kpiQuery = useGetDashboardKpis()
  const runsQuery = useGetRecentGenerationRuns()
  const projectsQuery = useGetContinueWorkingProjects()
  const risksQuery = useGetRisksAssuranceItems()
  const decisionsQuery = useGetDecisionsNeeded()

  // Trigger all queries on mount / whenever currentOrgId changes.
  useEffect(() => {
    if (!currentOrgId) return
    const params = { orgId: currentOrgId }
    void kpiQuery.trigger(params).result.catch(() => {})
    void runsQuery.trigger(params).result.catch(() => {})
    void projectsQuery.trigger(params).result.catch(() => {})
    void risksQuery.trigger(params).result.catch(() => {})
    void decisionsQuery.trigger(params).result.catch(() => {})
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [currentOrgId])

  const refresh = (which: 'kpis' | 'runs' | 'projects' | 'risks' | 'decisions') => () => {
    if (!currentOrgId) return
    const params = { orgId: currentOrgId }
    const map = {
      kpis: kpiQuery,
      runs: runsQuery,
      projects: projectsQuery,
      risks: risksQuery,
      decisions: decisionsQuery,
    } as const
    void map[which].trigger(params, { skipCache: true }).result.catch(() => {})
  }

  const handleNewProject = () => navigate('/wizard')
  const handleGenerateArtefacts = () => {
    if (!selectedProjectId) {
      toast.warning('Select a project first', {
        description: 'Open a project from Continue Working before generating artefacts.',
      })
      return
    }
    navigate('/charter')
  }

  const handleProjectRowClick = (row: ContinueWorkingProjectRow) => {
    setAppState({ selectedProjectId: row.project_id })
    navigate('/charter')
  }

  const kpis = (kpiQuery.data as DashboardKpis | null) ?? null

  // ---- Column definitions ---------------------------------------------------

  const runsColumns = useMemo<ColumnDef<RecentGenerationRunRow, any>[]>(
    () => [
      { accessorKey: 'project_name', header: 'Project' },
      { accessorKey: 'run_status', header: 'Run Status' },
      { accessorKey: 'current_stage', header: 'Current Stage' },
      {
        accessorKey: 'completed_at',
        header: 'Completed At',
        cell: (info) => formatDateTime(info.getValue() as string | null),
      },
      { accessorKey: 'action_label', header: 'Action' },
    ],
    [],
  )

  const projectsColumns = useMemo<ColumnDef<ContinueWorkingProjectRow, any>[]>(
    () => [
      { accessorKey: 'project_name', header: 'Project' },
      { accessorKey: 'lifecycle_stage', header: 'Stage' },
      { accessorKey: 'status', header: 'Status' },
      {
        accessorKey: 'last_updated_at',
        header: 'Last Updated',
        cell: (info) => formatDateTime(info.getValue() as string | null),
      },
      { accessorKey: 'action_label', header: 'Action' },
    ],
    [],
  )

  const risksColumns = useMemo<ColumnDef<RiskAssuranceRow, any>[]>(
    () => [
      { accessorKey: 'project_name', header: 'Project' },
      { accessorKey: 'risk_or_assurance_item', header: 'Risk / Assurance Item' },
      { accessorKey: 'severity', header: 'Severity' },
      { accessorKey: 'owner', header: 'Owner' },
      { accessorKey: 'status', header: 'Status' },
    ],
    [],
  )

  const decisionsColumns = useMemo<ColumnDef<DecisionNeededRow, any>[]>(
    () => [
      { accessorKey: 'project_name', header: 'Project' },
      { accessorKey: 'decision_needed', header: 'Decision Needed' },
      { accessorKey: 'priority', header: 'Priority' },
      {
        accessorKey: 'due_date',
        header: 'Due Date',
        cell: (info) => formatDateTime(info.getValue() as string | null),
      },
    ],
    [],
  )

  // ---- Render ---------------------------------------------------------------

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <p className="text-sm text-muted-foreground">
          Project intelligence, governance status, and delivery readiness.
        </p>
        <div className="flex items-center gap-2">
          <Button onClick={handleNewProject}>
            <Plus className="w-4 h-4" />
            <span>New Project</span>
          </Button>
          <Button variant="outline" onClick={handleGenerateArtefacts}>
            <Sparkles className="w-4 h-4" />
            <span>Generate Artefacts</span>
          </Button>
        </div>
      </div>

      {/* KPI cards */}
      <div className="grid grid-cols-2 gap-3 md:grid-cols-3 lg:grid-cols-6">
        <KpiCard
          label="Active Projects"
          value={kpis?.active_projects}
          loading={kpiQuery.loading && !kpis}
        />
        <KpiCard
          label="Projects Requiring Decision"
          value={kpis?.projects_requiring_decision}
          loading={kpiQuery.loading && !kpis}
        />
        <KpiCard
          label="Artefacts Generated"
          value={kpis?.artefacts_generated}
          loading={kpiQuery.loading && !kpis}
        />
        <KpiCard
          label="Open Risks"
          value={kpis?.open_risks}
          loading={kpiQuery.loading && !kpis}
        />
        <KpiCard
          label="Runs Completed"
          value={kpis?.runs_completed}
          loading={kpiQuery.loading && !kpis}
        />
        <KpiCard
          label="Items Needing Review"
          value={kpis?.items_needing_review}
          loading={kpiQuery.loading && !kpis}
        />
      </div>

      {/* Tables */}
      <div className="grid grid-cols-1 gap-6 xl:grid-cols-2">
        <DataTable<RecentGenerationRunRow>
          title="Recent Generation Runs"
          columns={runsColumns}
          data={runsQuery.data as RecentGenerationRunRow[] | null}
          loading={runsQuery.loading}
          error={runsQuery.error}
          onRefresh={refresh('runs')}
          exportFileName="recent-generation-runs"
        />
        <DataTable<ContinueWorkingProjectRow>
          title="Continue Working"
          columns={projectsColumns}
          data={projectsQuery.data as ContinueWorkingProjectRow[] | null}
          loading={projectsQuery.loading}
          error={projectsQuery.error}
          onRefresh={refresh('projects')}
          onRowClick={handleProjectRowClick}
          exportFileName="continue-working"
          emptyMessage="No projects yet. Use New Project to create one."
        />
        <DataTable<RiskAssuranceRow>
          title="Risks & Assurance"
          columns={risksColumns}
          data={risksQuery.data as RiskAssuranceRow[] | null}
          loading={risksQuery.loading}
          error={risksQuery.error}
          onRefresh={refresh('risks')}
          exportFileName="risks-assurance"
        />
        <DataTable<DecisionNeededRow>
          title="Decisions Needed"
          columns={decisionsColumns}
          data={decisionsQuery.data as DecisionNeededRow[] | null}
          loading={decisionsQuery.loading}
          error={decisionsQuery.error}
          onRefresh={refresh('decisions')}
          exportFileName="decisions-needed"
        />
      </div>
    </div>
  )
}
