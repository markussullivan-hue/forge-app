import { useEffect, useState } from 'react'
import { Link, useSearchParams } from 'react-router-dom'
import { useBackendFunction } from '../hooks/useBackendFunction'
import { Card, CardContent, CardHeader, CardTitle } from '../lib/shadcn/card'
import { Button } from '../lib/shadcn/button'
import Logo from '../components/Logo'

type VerifyState = 'loading' | 'ok' | 'invalid' | 'already_used' | 'expired' | 'unknown'

const MESSAGES: Record<VerifyState, string> = {
  loading: 'Verifying your account…',
  ok: '✅ Your email is verified. You can now sign in.',
  invalid: '⚠️ This verification link is invalid. Please check the link or request a new one.',
  already_used: 'ℹ️ This link has already been used. If your account is verified, you can sign in.',
  expired: '⚠️ This verification link has expired. Please request a new verification email.',
  unknown: '⚠️ Verification could not be completed. Please try again or request a new link.',
}

function toState(status: string | null | undefined): VerifyState {
  switch (status) {
    case 'ok':
    case 'invalid':
    case 'already_used':
    case 'expired':
      return status
    default:
      return 'unknown'
  }
}

export default function VerifyPage() {
  const [searchParams] = useSearchParams()
  const token = searchParams.get('token') ?? ''
  const verifyAccount = useBackendFunction('/backend/auth/verifyAccount.ts')
  const [state, setState] = useState<VerifyState>('loading')

  useEffect(() => {
    let cancelled = false

    if (!token) {
      setState('invalid')
      return
    }

    ;(async () => {
      try {
        const result = await verifyAccount.trigger({ token }).result
        if (cancelled) return
        const status =
          result && typeof result === 'object' && 'status' in result
            ? ((result as { status?: string | null }).status ?? null)
            : null
        setState(toState(status))
      } catch {
        if (!cancelled) setState('unknown')
      }
    })()

    return () => {
      cancelled = true
    }
    // Intentionally only run on token change.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [token])

  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-white dark:bg-black text-foreground px-4 py-8 gap-6">
      <Logo size="lg" />
      <Card className="w-full max-w-md shadow-retool-md">
        <CardHeader className="text-center">
          <CardTitle className="text-2xl font-bold">Account verification</CardTitle>
        </CardHeader>
        <CardContent className="space-y-6 text-center">
          <p className="text-base text-foreground" role="status" aria-live="polite">
            {MESSAGES[state]}
          </p>
          {state === 'ok' ? (
            <Button asChild className="w-full">
              <Link to="/login">Go to sign in</Link>
            </Button>
          ) : null}
          {state !== 'ok' && state !== 'loading' ? (
            <p className="text-sm text-muted-foreground">
              <Link to="/login" className="text-primary hover:underline">
                Return to sign in
              </Link>
            </p>
          ) : null}
        </CardContent>
      </Card>
    </div>
  )
}
