// Mirrors /context/linked-classic-app/src/containerGenerationError.rsx.
// Rendered inside ConfirmGenerationModal when generationStatus === 'error'.

import { AlertTriangle } from 'lucide-react'
import { Button } from '../../lib/shadcn/button'

type Props = {
  errorMessage: string | null
  onClose: () => void
  onRetry: () => void
}

export default function GenerationErrorPanel({
  errorMessage,
  onClose,
  onRetry,
}: Props) {
  return (
    <div className="space-y-3">
      <div className="flex items-center justify-center gap-2 rounded-md bg-destructive/10 text-destructive px-3 py-2">
        <AlertTriangle className="w-5 h-5" />
        <p className="font-medium text-sm">
          Generation failed — the project record was created, but the artefact
          pack was not.
        </p>
      </div>
      <p className="text-sm text-center text-muted-foreground whitespace-pre-wrap">
        {errorMessage || 'No error details available.'}
      </p>
      <p className="text-xs text-center text-muted-foreground">
        You can retry the generation, or close this window and try again later
        from the project dashboard.
      </p>
      <div className="flex justify-center gap-2">
        <Button type="button" variant="outline" onClick={onClose}>
          Close
        </Button>
        <Button type="button" onClick={onRetry}>
          Try again
        </Button>
      </div>
    </div>
  )
}
