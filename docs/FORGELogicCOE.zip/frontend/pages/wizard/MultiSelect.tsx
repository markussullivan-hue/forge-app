// Simple multi-select built on shadcn Popover + Checkbox. Supports either
// string- or number-typed values via a generic.

import { useMemo, useState } from 'react'
import { Check, ChevronsUpDown, X } from 'lucide-react'
import { Button } from '../../lib/shadcn/button'
import { Checkbox } from '../../lib/shadcn/checkbox'
import { Popover, PopoverContent, PopoverTrigger } from '../../lib/shadcn/popover'
import { cn } from '../../lib/shadcn/utils'

export type MultiSelectOption<V extends string | number> = {
  value: V
  label: string
}

type Props<V extends string | number> = {
  options: MultiSelectOption<V>[]
  value: V[]
  onChange: (next: V[]) => void
  placeholder?: string
  disabled?: boolean
  className?: string
}

export function MultiSelect<V extends string | number>({
  options,
  value,
  onChange,
  placeholder = 'Select options',
  disabled,
  className,
}: Props<V>) {
  const [open, setOpen] = useState(false)
  const selectedLabels = useMemo(() => {
    const map = new Map<string, string>()
    for (const opt of options) map.set(String(opt.value), opt.label)
    return value.map((v) => map.get(String(v)) ?? String(v))
  }, [options, value])

  const toggle = (v: V) => {
    if (value.includes(v)) {
      onChange(value.filter((x) => x !== v))
    } else {
      onChange([...value, v])
    }
  }

  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <Button
          type="button"
          variant="outline"
          role="combobox"
          aria-expanded={open}
          disabled={disabled}
          className={cn(
            'w-full justify-between font-normal h-auto min-h-9 py-1.5',
            value.length === 0 && 'text-muted-foreground',
            className,
          )}
        >
          <div className="flex flex-wrap gap-1 items-center text-left">
            {value.length === 0 ? (
              <span>{placeholder}</span>
            ) : (
              selectedLabels.map((lbl, i) => (
                <span
                  key={`${lbl}-${i}`}
                  className="inline-flex items-center gap-1 rounded-md bg-secondary text-secondary-foreground px-1.5 py-0.5 text-xs"
                >
                  {lbl}
                  <X
                    className="w-3 h-3 cursor-pointer hover:text-foreground"
                    onClick={(e) => {
                      e.stopPropagation()
                      const v = value[i]
                      if (v !== undefined) toggle(v)
                    }}
                  />
                </span>
              ))
            )}
          </div>
          <ChevronsUpDown className="w-4 h-4 opacity-50 ml-2 shrink-0" />
        </Button>
      </PopoverTrigger>
      <PopoverContent className="p-0 w-[var(--radix-popover-trigger-width)]" align="start">
        <div className="max-h-72 overflow-y-auto py-1">
          {options.length === 0 ? (
            <div className="px-3 py-2 text-sm text-muted-foreground">No options</div>
          ) : (
            options.map((opt) => {
              const checked = value.includes(opt.value)
              return (
                <button
                  key={String(opt.value)}
                  type="button"
                  onClick={() => toggle(opt.value)}
                  className="flex items-center gap-2 w-full px-2 py-1.5 text-sm text-left hover:bg-accent hover:text-accent-foreground"
                >
                  <Checkbox checked={checked} className="pointer-events-none" />
                  <span className="flex-1 truncate">{opt.label}</span>
                  {checked ? <Check className="w-4 h-4 text-primary" /> : null}
                </button>
              )
            })
          )}
        </div>
      </PopoverContent>
    </Popover>
  )
}
