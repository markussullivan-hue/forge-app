// Temporary diagnostic page. NOT the real login path.
//
// Mounted at /diagnostics/credential-check. Calls BOTH:
//   1. /backend/auth/pingForgeDb.ts
//   2. /backend/auth/checkCredentialsFresh.ts
// from the SAME page, SAME build, SAME runtime, and renders two redacted
// envelopes side by side so that resource-binding behaviour can be compared
// per-function.
//
// Deliberately:
//   - never displays the submitted password,
//   - never displays password hashes, salts, tokens, secrets, connection
//     strings, or full user records,
//   - never creates a session,
//   - never redirects,
//   - never writes to localStorage / sessionStorage.
//
// Once both published-Production envelopes have been captured, this page can
// be removed without affecting the real login flow.

import { useState, type FormEvent } from 'react'
import { Loader2 } from 'lucide-react'
import {
  useCheckCredentialsFresh,
  usePingForgeDb,
} from '../hooks/backend/auth'
import { Button } from '../lib/shadcn/button'
import { Input } from '../lib/shadcn/input'
import { Label } from '../lib/shadcn/label'
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '../lib/shadcn/card'

const PING_PATH = '/backend/auth/pingForgeDb.ts'
const FRESH_PATH = '/backend/auth/checkCredentialsFresh.ts'
const RESOURCE_IDENTIFIER = 'forgeSupabaseShadow2'

/**
 * Common envelope shape that both functions are normalised into for the
 * side-by-side display. Every field is intentionally nullable so a missing
 * value is rendered as `null` rather than being silently omitted.
 */
type NormalisedEnvelope = {
  functionPath: string
  environment: string | null
  dbResourceIdentifier: string | null
  resourceHandlePresent: boolean | null
  resourceBoundBeforeSql: boolean | null
  sqlReached: boolean | null
  reachedDb: boolean | null
  credentialCheckReached: boolean | null
  outcome: string | null
  reason: string | null
  code: string | null
  diagnostic: string | null
}

function safeStringify(value: unknown): string {
  try {
    return JSON.stringify(value, null, 2)
  } catch {
    return String(value)
  }
}

function asString(v: unknown): string | null {
  return typeof v === 'string' && v.length > 0 ? v : null
}

function asBool(v: unknown): boolean | null {
  return typeof v === 'boolean' ? v : null
}

/**
 * Normalise the raw pingForgeDb.ts response into the shared envelope.
 *
 * IMPORTANT: do NOT collapse `boundInRuntime: false` into an "ok-looking"
 * response. The whole point of this diagnostic is to surface a missing
 * resource handle, so resourceHandlePresent / resourceBoundBeforeSql are
 * mirrored directly from `boundInRuntime`, and `outcome` is derived from
 * the actual reachedDb value rather than a generic success flag.
 */
function normalisePing(raw: unknown): NormalisedEnvelope {
  const base: NormalisedEnvelope = {
    functionPath: PING_PATH,
    environment: null,
    dbResourceIdentifier: RESOURCE_IDENTIFIER,
    resourceHandlePresent: null,
    resourceBoundBeforeSql: null,
    sqlReached: null,
    reachedDb: null,
    credentialCheckReached: null, // N/A for ping — no credential check stage
    outcome: null,
    reason: null,
    code: null,
    diagnostic: null,
  }
  if (!raw || typeof raw !== 'object') return base
  const r = raw as Record<string, unknown>

  const boundInRuntime = asBool(r['boundInRuntime'])
  const reachedDb = asBool(r['reachedDb'])
  base.resourceHandlePresent = boundInRuntime
  // pingForgeDb only has a single binding probe; the closest equivalent of
  // "bound before SQL" is the same boundInRuntime flag.
  base.resourceBoundBeforeSql = boundInRuntime
  // pingForgeDb does not distinguish "SQL reached" from "DB reached"; expose
  // both, mapped from reachedDb, so the side-by-side comparison stays honest.
  base.sqlReached = reachedDb
  base.reachedDb = reachedDb

  const err = r['error']
  let errName: string | null = null
  let errCode: string | null = null
  let errMessage: string | null = null
  if (err && typeof err === 'object') {
    const e = err as Record<string, unknown>
    errName = asString(e['name'])
    errCode = asString(e['code'])
    errMessage = asString(e['message'])
  }

  // Derive outcome STRICTLY from the actual returned values so a missing
  // binding cannot hide behind a generic "ok" envelope.
  if (boundInRuntime === false) {
    base.outcome = 'backend_error'
    base.reason = 'resource_not_bound'
    base.code = errCode ?? 'RESOURCE_NOT_INJECTED'
  } else if (reachedDb === true) {
    base.outcome = 'ok'
    base.reason = 'db_round_trip_succeeded'
    base.code = null
  } else if (boundInRuntime === true && reachedDb === false) {
    base.outcome = 'backend_error'
    base.reason = 'sql_failed'
    base.code = errCode
  } else {
    base.outcome = 'unknown'
    base.reason = null
    base.code = errCode
  }

  const diagnosticParts: string[] = []
  if (errName) diagnosticParts.push(`name=${errName}`)
  if (errCode) diagnosticParts.push(`code=${errCode}`)
  if (errMessage) diagnosticParts.push(`message=${errMessage}`)
  base.diagnostic = diagnosticParts.length > 0 ? diagnosticParts.join('; ') : null

  return base
}

/**
 * Normalise the raw checkCredentialsFresh.ts response into the shared
 * envelope. The function already returns the exact field names we need.
 */
function normaliseFresh(raw: unknown): NormalisedEnvelope {
  const base: NormalisedEnvelope = {
    functionPath: FRESH_PATH,
    environment: null,
    dbResourceIdentifier: RESOURCE_IDENTIFIER,
    resourceHandlePresent: null,
    resourceBoundBeforeSql: null,
    sqlReached: null,
    reachedDb: null,
    credentialCheckReached: null,
    outcome: null,
    reason: null,
    code: null,
    diagnostic: null,
  }
  if (!raw || typeof raw !== 'object') return base
  const r = raw as Record<string, unknown>

  base.functionPath = asString(r['functionPath']) ?? FRESH_PATH
  base.environment = asString(r['environment'])
  base.dbResourceIdentifier =
    asString(r['dbResourceIdentifier']) ?? RESOURCE_IDENTIFIER
  base.resourceHandlePresent = asBool(r['resourceHandlePresent'])
  base.resourceBoundBeforeSql = asBool(r['resourceBoundBeforeSql'])
  const sqlReached = asBool(r['sqlReached'])
  base.sqlReached = sqlReached
  // No separate reachedDb field on this function; closest equivalent is
  // sqlReached (the round-trip went out to the DB).
  base.reachedDb = sqlReached
  base.credentialCheckReached = asBool(r['credentialCheckReached'])
  base.outcome = asString(r['outcome'])
  base.reason = asString(r['reason'])
  base.code = asString(r['code'])
  base.diagnostic = asString(r['diagnostic'])

  return base
}

/**
 * Ordered list of fields rendered in each envelope card. Order is fixed so
 * the two columns line up row-for-row for visual diffing.
 */
const FIELDS: ReadonlyArray<{
  key: keyof NormalisedEnvelope
  label: string
}> = [
  { key: 'functionPath', label: 'functionPath' },
  { key: 'environment', label: 'environment' },
  { key: 'dbResourceIdentifier', label: 'dbResourceIdentifier' },
  { key: 'resourceHandlePresent', label: 'resourceHandlePresent' },
  { key: 'resourceBoundBeforeSql', label: 'resourceBoundBeforeSql' },
  { key: 'sqlReached', label: 'sqlReached' },
  { key: 'reachedDb', label: 'reachedDb' },
  { key: 'credentialCheckReached', label: 'credentialCheckReached' },
  { key: 'outcome', label: 'outcome' },
  { key: 'reason', label: 'reason' },
  { key: 'code', label: 'code' },
  { key: 'diagnostic', label: 'diagnostic' },
]

function renderValue(v: unknown): string {
  if (v === null) return 'null'
  if (v === undefined) return 'undefined'
  if (typeof v === 'boolean') return v ? 'true' : 'false'
  return String(v)
}

export default function CredentialDiagnosticPage() {
  const ping = usePingForgeDb()
  const fresh = useCheckCredentialsFresh()
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [pingResponse, setPingResponse] = useState<unknown>(null)
  const [freshResponse, setFreshResponse] = useState<unknown>(null)
  const [pingError, setPingError] = useState<string | null>(null)
  const [freshError, setFreshError] = useState<string | null>(null)

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault()
    setPingResponse(null)
    setFreshResponse(null)
    setPingError(null)
    setFreshError(null)

    // Fire both calls from the SAME page action so they share runtime, build,
    // and environment context. Run them in parallel to keep timing tight.
    const pingPromise = ping
      .trigger({}, { skipCache: true })
      .result.then(
        (r) => setPingResponse(r),
        (err: unknown) =>
          setPingError(err instanceof Error ? err.message : String(err)),
      )
    const freshPromise = fresh
      .trigger({ email, password }, { skipCache: true })
      .result.then(
        (r) => setFreshResponse(r),
        (err: unknown) =>
          setFreshError(err instanceof Error ? err.message : String(err)),
      )
    await Promise.allSettled([pingPromise, freshPromise])
  }

  const pingEnv = normalisePing(pingResponse)
  const freshEnv = normaliseFresh(freshResponse)
  const anyLoading = ping.loading || fresh.loading

  return (
    <div className="min-h-screen bg-background text-foreground p-6 flex justify-center">
      <div className="w-full max-w-6xl space-y-4">
        <Card>
          <CardHeader>
            <CardTitle>
              Credential-check diagnostic (side-by-side)
            </CardTitle>
            <CardDescription>
              Diagnostic-only. Calls both{' '}
              <code className="font-mono text-xs">{PING_PATH}</code> and{' '}
              <code className="font-mono text-xs">{FRESH_PATH}</code> from the
              same page, build, and runtime. No session is created. No
              redirect occurs. The submitted password, password hashes,
              salts, tokens, secrets, connection strings, and full user
              records are never rendered.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-3">
              <div className="space-y-1">
                <Label htmlFor="diag-email">Email</Label>
                <Input
                  id="diag-email"
                  type="email"
                  autoComplete="off"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                />
              </div>
              <div className="space-y-1">
                <Label htmlFor="diag-password">Password</Label>
                <Input
                  id="diag-password"
                  type="password"
                  autoComplete="off"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                />
                <p className="text-xs text-muted-foreground">
                  The submitted value is sent to the backend but is never
                  rendered back to this page.
                </p>
              </div>
              <Button type="submit" disabled={anyLoading}>
                {anyLoading ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Running both diagnostics…
                  </>
                ) : (
                  'Run both diagnostics'
                )}
              </Button>
            </form>
          </CardContent>
        </Card>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <EnvelopeCard
            title="pingForgeDb.ts"
            description="Resource-binding + DB round-trip probe. resourceHandlePresent here mirrors boundInRuntime from the function; a false value is surfaced directly and is NOT collapsed into an ok-looking response."
            envelope={pingEnv}
            loading={ping.loading}
            hookError={ping.error}
            submitError={pingError}
            raw={pingResponse}
          />
          <EnvelopeCard
            title="checkCredentialsFresh.ts"
            description="Fresh credential-check diagnostic. Same resource identifier, same runtime as the ping call above."
            envelope={freshEnv}
            loading={fresh.loading}
            hookError={fresh.error}
            submitError={freshError}
            raw={freshResponse}
          />
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Notes on the displayed values</CardTitle>
          </CardHeader>
          <CardContent className="text-xs text-muted-foreground space-y-2">
            <p>
              <strong>environment:</strong> sourced via{' '}
              <code className="font-mono">process.env</code> on the backend
              (<code className="font-mono">RETOOL_ENVIRONMENT</code>,{' '}
              <code className="font-mono">RETOOL_RELEASE_ENV</code>,{' '}
              <code className="font-mono">NODE_ENV</code>). In Retool R2 code
              apps, <code className="font-mono">process</code> /{' '}
              <code className="font-mono">process.env</code> is not
              guaranteed to be populated in the serverless runtime, so a
              <code className="font-mono"> null</code> value here is
              expected for this app type and does not by itself indicate a
              binding problem.{' '}
              <code className="font-mono">pingForgeDb.ts</code> does not
              expose an environment field, so its column is shown as{' '}
              <code className="font-mono">null</code>.
            </p>
            <p>
              <strong>resourceHandlePresent (pingForgeDb):</strong> mirrored
              from <code className="font-mono">boundInRuntime</code>. If the
              function returns{' '}
              <code className="font-mono">boundInRuntime: false</code>, this
              column displays <code className="font-mono">false</code> and
              the outcome is reported as{' '}
              <code className="font-mono">backend_error</code> /{' '}
              <code className="font-mono">resource_not_bound</code> — the
              typeof guard inside the backend does not silently produce an
              ok-looking envelope here.
            </p>
            <p>
              <strong>reachedDb / sqlReached:</strong>{' '}
              <code className="font-mono">pingForgeDb.ts</code> reports
              <code className="font-mono"> reachedDb</code>; this page
              mirrors it into <code className="font-mono">sqlReached</code>{' '}
              for symmetry.{' '}
              <code className="font-mono">checkCredentialsFresh.ts</code>{' '}
              reports <code className="font-mono">sqlReached</code>; this
              page mirrors it into <code className="font-mono">reachedDb</code>{' '}
              for the same reason.
            </p>
            <p>
              <strong>credentialCheckReached:</strong> only meaningful for{' '}
              <code className="font-mono">checkCredentialsFresh.ts</code>.
              For <code className="font-mono">pingForgeDb.ts</code> it is{' '}
              <code className="font-mono">null</code> (N/A — no credential
              stage exists in that function).
            </p>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

function EnvelopeCard({
  title,
  description,
  envelope,
  loading,
  hookError,
  submitError,
  raw,
}: {
  title: string
  description: string
  envelope: NormalisedEnvelope
  loading: boolean
  hookError: string | null
  submitError: string | null
  raw: unknown
}) {
  return (
    <Card>
      <CardHeader>
        <CardTitle className="font-mono text-base">{title}</CardTitle>
        <CardDescription>{description}</CardDescription>
      </CardHeader>
      <CardContent className="space-y-3">
        <div className="grid grid-cols-[max-content_1fr] gap-x-3 gap-y-1 text-xs font-mono">
          <span className="text-muted-foreground">loading</span>
          <span>{String(loading)}</span>
          <span className="text-muted-foreground">hook.error</span>
          <span className="break-all">{hookError ?? '(none)'}</span>
          <span className="text-muted-foreground">submitError</span>
          <span className="break-all">{submitError ?? '(none)'}</span>
        </div>
        <div className="border-t border-border pt-2">
          <div className="grid grid-cols-[max-content_1fr] gap-x-3 gap-y-1 text-xs font-mono">
            {FIELDS.map((f) => (
              <KV
                key={f.key}
                k={f.label}
                v={renderValue(envelope[f.key])}
                muted={envelope[f.key] === null}
              />
            ))}
          </div>
        </div>
        <details>
          <summary className="text-xs text-muted-foreground cursor-pointer">
            Raw response (already redacted server-side)
          </summary>
          <pre className="mt-2 p-3 rounded bg-muted text-foreground text-xs whitespace-pre-wrap break-all">
            {raw == null ? '(no response yet)' : safeStringify(raw)}
          </pre>
        </details>
      </CardContent>
    </Card>
  )
}

function KV({
  k,
  v,
  muted,
}: {
  k: string
  v: string
  muted?: boolean
}) {
  return (
    <>
      <span className="text-muted-foreground">{k}</span>
      <span
        className={'break-all ' + (muted ? 'text-muted-foreground' : '')}
        title={v}
      >
        {v}
      </span>
    </>
  )
}
