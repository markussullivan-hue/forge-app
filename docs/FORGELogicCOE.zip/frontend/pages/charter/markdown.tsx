// Minimal-scope markdown renderer for the charter page.
//
// Supports the limited subset emitted by the classic Retool app:
//   #, ##, ###, ####, ###### headings
//   **bold**, *italic*, `code`
//   - bullet lists
//   blank-line-separated paragraphs
//
// We intentionally avoid a full markdown engine here — package installs are
// disabled during conversion, and the artefact bodies stay within this subset.

import { Fragment, type ReactNode } from 'react'

type InlineNode = string | { kind: 'bold' | 'italic' | 'code'; text: string }

function parseInline(text: string): InlineNode[] {
  const nodes: InlineNode[] = []
  let i = 0
  let buffer = ''

  const flush = () => {
    if (buffer) {
      nodes.push(buffer)
      buffer = ''
    }
  }

  while (i < text.length) {
    const c2 = text.slice(i, i + 2)
    if (c2 === '**') {
      const end = text.indexOf('**', i + 2)
      if (end !== -1) {
        flush()
        nodes.push({ kind: 'bold', text: text.slice(i + 2, end) })
        i = end + 2
        continue
      }
    }
    const c1 = text[i]
    if (c1 === '*') {
      const end = text.indexOf('*', i + 1)
      if (end !== -1) {
        flush()
        nodes.push({ kind: 'italic', text: text.slice(i + 1, end) })
        i = end + 1
        continue
      }
    }
    if (c1 === '`') {
      const end = text.indexOf('`', i + 1)
      if (end !== -1) {
        flush()
        nodes.push({ kind: 'code', text: text.slice(i + 1, end) })
        i = end + 1
        continue
      }
    }
    buffer += c1
    i += 1
  }
  flush()
  return nodes
}

function renderInline(text: string): ReactNode {
  return parseInline(text).map((node, idx) => {
    if (typeof node === 'string') return <Fragment key={idx}>{node}</Fragment>
    if (node.kind === 'bold') return <strong key={idx}>{node.text}</strong>
    if (node.kind === 'italic') return <em key={idx}>{node.text}</em>
    return (
      <code key={idx} className="px-1 py-0.5 rounded bg-muted text-foreground text-[0.9em] font-mono">
        {node.text}
      </code>
    )
  })
}

export function Markdown({ children, className = '' }: { children: string | null | undefined; className?: string }) {
  const text = children ?? ''
  if (!text) return null

  const lines = text.replace(/\r\n/g, '\n').split('\n')
  const blocks: ReactNode[] = []
  let paragraph: string[] = []
  let list: string[] = []
  let codeFence: string[] | null = null

  const flushParagraph = () => {
    if (!paragraph.length) return
    const txt = paragraph.join(' ').trim()
    paragraph = []
    if (txt) {
      blocks.push(
        <p key={`p-${blocks.length}`} className="text-sm text-foreground leading-relaxed">
          {renderInline(txt)}
        </p>,
      )
    }
  }

  const flushList = () => {
    if (!list.length) return
    const items = list
    list = []
    blocks.push(
      <ul key={`ul-${blocks.length}`} className="list-disc pl-6 text-sm text-foreground space-y-1">
        {items.map((item, idx) => (
          <li key={idx}>{renderInline(item)}</li>
        ))}
      </ul>,
    )
  }

  const flushCode = () => {
    if (!codeFence) return
    const code = codeFence.join('\n')
    codeFence = null
    blocks.push(
      <pre key={`pre-${blocks.length}`} className="bg-muted text-foreground rounded-md p-3 text-xs font-mono overflow-x-auto whitespace-pre-wrap">
        {code}
      </pre>,
    )
  }

  const headingClass = (level: number): string => {
    if (level === 1) return 'text-2xl font-bold mt-2 mb-2'
    if (level === 2) return 'text-xl font-semibold mt-2 mb-2'
    if (level === 3) return 'text-lg font-semibold mt-2 mb-1'
    if (level === 4) return 'text-base font-semibold mt-1 mb-1'
    if (level === 5) return 'text-sm font-semibold mt-1 mb-1'
    return 'text-xs font-semibold mt-1 mb-1 text-muted-foreground'
  }

  for (const raw of lines) {
    const line = raw

    // Code fence start/end
    if (line.trim().startsWith('```')) {
      if (codeFence) {
        flushCode()
      } else {
        flushParagraph()
        flushList()
        codeFence = []
      }
      continue
    }
    if (codeFence) {
      codeFence.push(line)
      continue
    }

    if (!line.trim()) {
      flushParagraph()
      flushList()
      continue
    }

    const headingMatch = /^(#{1,6})\s+(.*)$/.exec(line)
    if (headingMatch) {
      flushParagraph()
      flushList()
      const level = headingMatch[1]!.length
      const Tag = (`h${Math.min(level, 6)}`) as 'h1' | 'h2' | 'h3' | 'h4' | 'h5' | 'h6'
      blocks.push(
        <Tag key={`h-${blocks.length}`} className={headingClass(level)}>
          {renderInline(headingMatch[2]!)}
        </Tag>,
      )
      continue
    }

    const bulletMatch = /^\s*[-*]\s+(.*)$/.exec(line)
    if (bulletMatch) {
      flushParagraph()
      list.push(bulletMatch[1]!)
      continue
    }

    paragraph.push(line.trim())
  }

  flushCode()
  flushParagraph()
  flushList()

  return <div className={className}>{blocks}</div>
}
