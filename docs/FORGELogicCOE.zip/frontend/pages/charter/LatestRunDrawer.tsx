import type { ReactNode } from 'react'
import { Button } from '../../lib/shadcn/button'
import {
  Sheet,
  SheetClose,
  SheetContent,
  SheetFooter,
  SheetHeader,
  SheetTitle,
} from '../../lib/shadcn/sheet'
import type { GenerationRunRow } from './derivations'

const ABS_DATE = new Intl.DateTimeFormat(undefined, {
  day: '2-digit',
  month: 'short',
  year: 'numeric',
  hour: '2-digit',
  minute: '2-digit',
})

function fmtDate(value: string | null | undefined): string {
  if (!value) return '—'
  const d = new Date(value)
  if (Number.isNaN(d.getTime())) return '—'
  return ABS_DATE.format(d)
}

function fmtDuration(value: number | string | null | undefined): string {
  if (value === null || value === undefined || value === '') return '—'
  const n = Number(value)
  if (!Number.isFinite(n) || n <= 0) return '—'
  const totalSeconds = Math.round(n / 1000)
  if (totalSeconds < 60) return `${totalSeconds}s`
  const mins = Math.floor(totalSeconds / 60)
  const secs = totalSeconds % 60
  return `${mins}m ${secs}s`
}

function fmtStages(value: unknown): string {
  if (Array.isArray(value) && value.length) {
    return value.map((x) => String(x)).filter(Boolean).join(' → ')
  }
  if (typeof value === 'string' && value.trim() !== '') {
    return value
      .split(',')
      .map((s) => s.trim())
      .filter(Boolean)
      .join(' → ')
  }
  return '—'
}

function Row({ label, children }: { label: string; children: ReactNode }) {
  return (
    <div className="flex flex-col gap-0.5">
      <div className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">{label}</div>
      <div className="text-sm text-foreground break-words">{children}</div>
    </div>
  )
}

export default function LatestRunDrawer({
  open,
  onOpenChange,
  run,
}: {
  open: boolean
  onOpenChange: (open: boolean) => void
  run: GenerationRunRow | null
}) {
  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent side="right" className="w-full sm:max-w-md flex flex-col">
        <SheetHeader>
          <SheetTitle>Latest generation run</SheetTitle>
        </SheetHeader>

        <div className="flex-1 overflow-y-auto space-y-3 pt-2">
          <Row label="Status">{run?.status || 'No run found'}</Row>
          <Row label="Current stage">{run?.current_stage || '—'}</Row>
          <Row label="Completed stages">{fmtStages(run?.stages_completed)}</Row>
          <Row label="Started at">{fmtDate(run?.started_at)}</Row>
          <Row label="Completed at">{fmtDate(run?.completed_at)}</Row>
          <Row label="Updated at">{fmtDate(run?.updated_at)}</Row>
          <Row label="Duration">{fmtDuration(run?.total_duration_ms)}</Row>
          <Row label="Initiated by">{run?.initiated_by_email || '—'}</Row>
          <Row label="Run ID">{run?.run_id || '—'}</Row>
          <Row label="Workflow run ID">{run?.workflow_run_id || '—'}</Row>
          <Row label="Correlation ID">{run?.correlation_id || '—'}</Row>
          <Row label="Error message">
            <pre className="mt-1 p-3 bg-muted rounded-md text-xs font-mono whitespace-pre-wrap text-foreground">
              {run?.error_message || 'No error recorded.'}
            </pre>
          </Row>
        </div>

        <SheetFooter>
          <SheetClose asChild>
            <Button variant="outline">Close</Button>
          </SheetClose>
        </SheetFooter>
      </SheetContent>
    </Sheet>
  )
}
