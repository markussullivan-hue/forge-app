import { Download, ExternalLink } from 'lucide-react'
import { Button } from '../../lib/shadcn/button'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../../lib/shadcn/tabs'
import PdfViewer, { type PdfRow } from './renderers/PdfViewer'
import DynamicRegister from './renderers/DynamicRegister'
import Narrative from './renderers/Narrative'
import RegisterTable from './renderers/RegisterTable'
import { Markdown } from './markdown'
import {
  formatGeneratedAt,
  type ActiveArtefact,
  type OrderedArtefact,
} from './derivations'

function ArtefactHeader({ artefact, pdf }: { artefact: ActiveArtefact; pdf: PdfRow | null }) {
  if (artefact.pattern === 'empty') {
    return <h2 className="text-xl font-semibold">Select a Project to render artefacts</h2>
  }

  if (artefact.pattern === 'pdf_viewer') {
    const status = pdf?.pdfmonkey_status ? ` | ${pdf.pdfmonkey_status}` : ''
    const filename = pdf?.pdfmonkey_filename ? `  (${pdf.pdfmonkey_filename})` : ''
    return (
      <div className="space-y-1">
        <h2 className="text-xl font-semibold text-foreground">
          {artefact.artefact_name}
          {filename}
        </h2>
        <p className="text-xs italic text-muted-foreground">
          Generated {formatGeneratedAt(pdf?.run_completed_at ?? null)}
          {status}
        </p>
      </div>
    )
  }

  const v = artefact.version_number ?? '-'
  const email = artefact.generated_by_email_snapshot || 'Unknown user'
  return (
    <div className="space-y-1">
      <h2 className="text-xl font-semibold text-foreground">{artefact.artefact_name}</h2>
      <p className="text-xs italic text-muted-foreground">
        Version {v} | Generated {formatGeneratedAt(artefact.generated_at)} | by {email}
      </p>
    </div>
  )
}

function ArtefactBody({
  artefact,
  pdf,
  fallbackMarkdown,
}: {
  artefact: ActiveArtefact
  pdf: PdfRow | null
  fallbackMarkdown: string | null
}) {
  if (artefact.pattern === 'empty') {
    return <p className="text-sm italic text-muted-foreground">No artefact selected.</p>
  }
  if (artefact.pattern === 'pdf_viewer') return <PdfViewer pdf={pdf} />
  if (artefact.pattern === 'dynamic_register') return <DynamicRegister artefact={artefact} />
  if (artefact.pattern === 'narrative') return <Narrative artefact={artefact} />
  if (artefact.pattern === 'register_table') return <RegisterTable artefact={artefact} />

  // Unknown / markdown fallback — try to render content_markdown if present.
  if (fallbackMarkdown && fallbackMarkdown.trim()) {
    return <Markdown>{fallbackMarkdown}</Markdown>
  }
  return <p className="text-sm italic text-muted-foreground">No content available.</p>
}

export default function ArtefactTabs({
  orderedArtefacts,
  selectedArtefactCode,
  onSelectArtefact,
  activeArtefact,
  pdf,
  fallbackMarkdown,
}: {
  orderedArtefacts: OrderedArtefact[]
  selectedArtefactCode: string | null
  onSelectArtefact: (code: string) => void
  activeArtefact: ActiveArtefact
  pdf: PdfRow | null
  fallbackMarkdown: string | null
}) {
  const tabs = orderedArtefacts
  const fallbackCode = tabs[0]?.artefact_code ?? ''
  const value = selectedArtefactCode && tabs.some((t) => t.artefact_code === selectedArtefactCode)
    ? selectedArtefactCode
    : fallbackCode

  if (!tabs.length) {
    return (
      <div className="rounded-md border border-dashed border-border p-6 text-sm italic text-muted-foreground">
        Select a project to render artefacts.
      </div>
    )
  }

  const previewUrl = pdf?.pdfmonkey_preview_url ?? null
  const downloadUrl = pdf?.pdfmonkey_download_url ?? null

  return (
    <div className="space-y-4">
      <Tabs value={value} onValueChange={onSelectArtefact}>
        <TabsList className="flex flex-wrap h-auto gap-1">
          {tabs.map((t) => (
            <TabsTrigger key={t.artefact_code} value={t.artefact_code}>
              {t.artefact_name}
            </TabsTrigger>
          ))}
        </TabsList>

        {tabs.map((t) => (
          <TabsContent key={t.artefact_code} value={t.artefact_code} className="mt-4">
            {t.artefact_code === value ? (
              <div className="rounded-md border border-border bg-card text-card-foreground p-4 space-y-4">
                <ArtefactHeader artefact={activeArtefact} pdf={pdf} />
                <ArtefactBody artefact={activeArtefact} pdf={pdf} fallbackMarkdown={fallbackMarkdown} />
              </div>
            ) : null}
          </TabsContent>
        ))}
      </Tabs>

      <div className="flex flex-wrap items-center gap-2">
        <Button
          variant="outline"
          disabled={!previewUrl}
          title={previewUrl ? 'Open the generated PDF preview.' : 'PDF preview is not available yet.'}
          onClick={() => {
            if (previewUrl) window.open(previewUrl, '_blank', 'noopener,noreferrer')
          }}
        >
          <ExternalLink className="w-4 h-4 mr-1" /> Preview PDF
        </Button>
        <Button
          disabled={!downloadUrl}
          title={downloadUrl ? 'Download the generated PDF.' : 'PDF download is not available yet.'}
          onClick={() => {
            if (downloadUrl) window.open(downloadUrl, '_blank', 'noopener,noreferrer')
          }}
        >
          <Download className="w-4 h-4 mr-1" /> Download PDF
        </Button>
      </div>
    </div>
  )
}
