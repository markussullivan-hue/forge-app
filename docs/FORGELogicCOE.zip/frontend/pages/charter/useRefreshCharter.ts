// Orchestrator hook: ports /context/linked-classic-app/lib/refreshCharterGenerationPage.js.
// Triggers the project selector, current artefacts, active PDF, generation
// runs, and observations queries in the same order as the classic flow.

import { useCallback } from 'react'
import {
  useGetActiveProjectPdf,
  useGetCurrentArtefactsForEntity,
  useGetCurrentObservationsForEntity,
  useGetGenerationRunsQuery,
  useGetProjectsForSelector,
} from '../../hooks/backend/charter'

export type CharterQueries = {
  projects: ReturnType<typeof useGetProjectsForSelector>
  artefacts: ReturnType<typeof useGetCurrentArtefactsForEntity>
  activePdf: ReturnType<typeof useGetActiveProjectPdf>
  runs: ReturnType<typeof useGetGenerationRunsQuery>
  observations: ReturnType<typeof useGetCurrentObservationsForEntity>
}

export function useCharterQueries(): CharterQueries {
  return {
    projects: useGetProjectsForSelector(),
    artefacts: useGetCurrentArtefactsForEntity(),
    activePdf: useGetActiveProjectPdf(),
    runs: useGetGenerationRunsQuery(),
    observations: useGetCurrentObservationsForEntity(),
  }
}

export function useRefreshCharter(
  queries: CharterQueries,
  args: { orgId: string | null; projectId: string | null; selectedArtefactCode: string | null },
) {
  const { projects, artefacts, activePdf, runs, observations } = queries
  const { orgId, projectId, selectedArtefactCode } = args

  return useCallback(
    async (options?: { skipCache?: boolean }): Promise<void> => {
      if (!orgId) return
      const skip = options?.skipCache ? { skipCache: true } : undefined

      // 1. Refresh project options for the org.
      await projects.trigger({ orgId }, skip).result.catch(() => {})
      if (!projectId) return

      // 2. Refresh project-scoped queries in parallel.
      const entityParams = { orgId, entityType: 'Project' as const, entityId: projectId }
      await Promise.all([
        artefacts.trigger(entityParams, skip).result.catch(() => {}),
        observations.trigger(entityParams, skip).result.catch(() => {}),
        activePdf
          .trigger({ orgId, projectId, artefactCode: selectedArtefactCode ?? null }, skip)
          .result.catch(() => {}),
        runs.trigger({ orgId, projectId }, skip).result.catch(() => {}),
      ])
    },
    [orgId, projectId, selectedArtefactCode, projects, artefacts, observations, activePdf, runs],
  )
}
