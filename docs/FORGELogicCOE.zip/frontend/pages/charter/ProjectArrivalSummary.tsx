import { Search } from 'lucide-react'
import { Button } from '../../lib/shadcn/button'
import { Card, CardContent } from '../../lib/shadcn/card'
import type { ProjectOption } from './ProjectSelectorBar'
import type { ArtefactMap, GenerationRunRow } from './derivations'

export default function ProjectArrivalSummary({
  selectedProjectId,
  projects,
  latestRun,
  artefactMap,
  onViewRunDetails,
}: {
  selectedProjectId: string | null
  projects: ProjectOption[]
  latestRun: GenerationRunRow | null
  artefactMap: ArtefactMap
  onViewRunDetails: () => void
}) {
  const selected = projects.find((p) => p.project_id === selectedProjectId) || null

  const projectLabel = (() => {
    if (!selectedProjectId) return 'No project selected'
    if (selected) {
      const name = selected.project_name && selected.project_name.trim() !== '' ? selected.project_name : '[Unnamed project]'
      const code = selected.project_code ? ` | ${selected.project_code}` : ''
      return `${name}${code}`
    }
    return `Selected project: ${selectedProjectId}`
  })()

  const artefactCount = Object.keys(artefactMap || {}).filter((k) => k !== 'pdf').length

  const pdfAvailable = (() => {
    const pdfRow = artefactMap['pdf']
    if (!pdfRow) return false
    const meta = pdfRow.additional_metadata_json as Record<string, unknown> | null | undefined
    if (!meta || typeof meta !== 'object') return false
    return !!(meta as Record<string, unknown>)['pdfmonkey_preview_url']
  })()

  return (
    <Card className="mt-3">
      <CardContent className="p-4 flex flex-col gap-2 lg:flex-row lg:flex-wrap lg:items-center lg:gap-x-6 lg:gap-y-1">
        <div className="text-sm text-foreground">
          <span className="font-semibold">Project:</span> {projectLabel}
        </div>
        <div className="text-sm text-foreground">
          <span className="font-semibold">Latest run:</span> {latestRun?.status || 'No generation run found'}
        </div>
        <div className="text-sm text-foreground">
          <span className="font-semibold">Stage:</span> {latestRun?.current_stage || '—'}
        </div>
        <div className="text-sm text-foreground">
          <span className="font-semibold">Current artefacts:</span> {artefactCount}
        </div>
        <div className="text-sm text-foreground">
          <span className="font-semibold">PDF:</span> {pdfAvailable ? 'Available' : 'Not available'}
        </div>
        <div className="lg:ml-auto">
          <Button
            variant="outline"
            size="sm"
            onClick={onViewRunDetails}
            disabled={!latestRun}
            title={latestRun ? 'View details for the latest generation run.' : 'No generation run found for this project.'}
          >
            <Search className="w-4 h-4 mr-1" /> View run details
          </Button>
        </div>
      </CardContent>
    </Card>
  )
}
