import { Plus, RefreshCw } from 'lucide-react'
import { Button } from '../../lib/shadcn/button'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '../../lib/shadcn/select'
import { Spinner } from '../../lib/shadcn/spinner'

export type ProjectOption = {
  project_id: string
  project_name: string | null
  project_code: string
}

function optionLabel(p: ProjectOption): string {
  const name = p.project_name && p.project_name.trim() !== '' ? p.project_name : '[Unnamed project]'
  return `${name} | ${p.project_code}`
}

export default function ProjectSelectorBar({
  projects,
  selectedProjectId,
  onProjectChange,
  onNewProject,
  onRegenerate,
  regenerating,
  canRegenerate,
}: {
  projects: ProjectOption[]
  selectedProjectId: string | null
  onProjectChange: (projectId: string) => void
  onNewProject: () => void
  onRegenerate: () => void
  regenerating: boolean
  canRegenerate: boolean
}) {
  return (
    <div className="flex flex-col gap-3 lg:flex-row lg:items-center lg:justify-between">
      <div className="flex flex-wrap items-center gap-2">
        <Button onClick={onNewProject}>
          <Plus className="w-4 h-4 mr-1" />
          New Project / Programme
        </Button>
        <Button
          variant="outline"
          onClick={onRegenerate}
          disabled={!canRegenerate || regenerating}
          title="Manually trigger initial artefact generation for an existing entity"
        >
          {regenerating ? (
            <Spinner className="w-4 h-4 mr-1" />
          ) : (
            <RefreshCw className="w-4 h-4 mr-1" />
          )}
          Re-Generate artefacts
        </Button>
      </div>

      <div className="min-w-[280px] lg:w-[360px]">
        <Select
          value={selectedProjectId ?? ''}
          onValueChange={(v) => {
            if (v) onProjectChange(v)
          }}
        >
          <SelectTrigger>
            <SelectValue placeholder="Select a project" />
          </SelectTrigger>
          <SelectContent>
            {projects.length === 0 ? (
              <div className="px-3 py-2 text-sm text-muted-foreground">No projects</div>
            ) : (
              projects.map((p) => (
                <SelectItem key={p.project_id} value={p.project_id}>
                  {optionLabel(p)}
                </SelectItem>
              ))
            )}
          </SelectContent>
        </Select>
      </div>
    </div>
  )
}
