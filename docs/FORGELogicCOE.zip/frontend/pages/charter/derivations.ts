// Pure-functional ports of the classic JS derivation queries used by the
// CharterGenerationPage. Each function maps to a file under
// /context/linked-classic-app/lib/.

// Local mirrors of the backend return-row shapes so the frontend doesn't
// pull in /backend/ types (the backend ambient globals — User,
// forgeSupabaseShadow2 — are not in the frontend tsconfig).

export type ArtefactRow = {
  version_id: string
  version_number: number | null
  is_current: boolean
  entity_type: string
  entity_id: string
  artefact_type_id: string | null
  delivery_model_artefact_id: string
  content_markdown: string | null
  content_metadata: unknown
  additional_metadata_json: unknown
  generated_at: string | null
  generated_by_email_snapshot: string | null
  artefact_code: string
  artefact_name: string
  sort_order: number
  canonical_artefact_type: string | null
  rendering_pattern: string | null
  model_code: string | null
  model_name: string | null
}

export type GenerationRunRow = {
  run_id: string
  org_id: string
  entity_type: string
  entity_id: string | null
  correlation_id: string | null
  workflow_run_id: string | null
  status: string | null
  current_stage: string | null
  stages_completed: unknown
  is_regeneration: boolean | null
  error_message: string | null
  total_duration_ms: number | null
  initiated_by_email: string | null
  started_at: string | null
  completed_at: string | null
  updated_at: string | null
  created_at: string | null
}

// ---- artefactMap.js --------------------------------------------------------

export type ArtefactMap = Record<string, ArtefactRow>

export function buildArtefactMap(rows: ArtefactRow[] | null | undefined): ArtefactMap {
  const list = Array.isArray(rows) ? rows : []
  return list.reduce<ArtefactMap>((acc, row) => {
    const key = String(row?.artefact_code || '').toLowerCase()
    if (!key) return acc
    acc[key] = row
    return acc
  }, {})
}

// ---- artefactsByType.js ----------------------------------------------------
// Classic implementation grouped by `type_code` (which is not present in our
// SQL projection). We re-implement against `canonical_artefact_type` to keep
// the same intent: "one record per artefact type".

export type ArtefactByType = ArtefactRow & {
  content_metadata_obj: unknown
  additional_metadata_obj: unknown
}

function parseMaybeJson(v: unknown): unknown {
  if (v == null) return null
  if (typeof v === 'object') return v
  if (typeof v === 'string') {
    const s = v.trim()
    if (!s) return null
    try {
      return JSON.parse(s)
    } catch {
      return null
    }
  }
  return null
}

export function buildArtefactsByType(rows: ArtefactRow[] | null | undefined): Record<string, ArtefactByType> {
  const list = Array.isArray(rows) ? rows : []
  const out: Record<string, ArtefactByType> = {}
  for (const r of list) {
    const type = String(r?.canonical_artefact_type || '').toLowerCase()
    if (!type) continue
    out[type] = {
      ...r,
      content_metadata_obj: parseMaybeJson(r.content_metadata),
      additional_metadata_obj: parseMaybeJson(r.additional_metadata_json),
    }
  }
  return out
}

// ---- orderedArtefacts.js ---------------------------------------------------

export type OrderedArtefact = {
  artefact_code: string
  artefact_name: string
  sort_order: number
  rendering_pattern: string | null
  canonical_artefact_type: string | null
  version_id: string | null
  version_number: number | null
  generated_at: string | null
  generated_by_email_snapshot: string | null
  content_metadata: unknown
  model_code: string | null
  model_name: string | null
}

export function buildOrderedArtefacts(map: ArtefactMap): OrderedArtefact[] {
  const list: OrderedArtefact[] = Object.values(map)
    .filter((row) => row && row.artefact_code)
    .sort((a, b) => Number(a.sort_order) - Number(b.sort_order))
    .map((row) => ({
      artefact_code: String(row.artefact_code).toLowerCase(),
      artefact_name: row.artefact_name,
      sort_order: Number(row.sort_order),
      rendering_pattern: row.rendering_pattern,
      canonical_artefact_type: row.canonical_artefact_type,
      version_id: row.version_id,
      version_number: row.version_number,
      generated_at: row.generated_at,
      generated_by_email_snapshot: row.generated_by_email_snapshot,
      content_metadata: row.content_metadata,
      model_code: row.model_code,
      model_name: row.model_name,
    }))

  list.push({
    artefact_code: 'pdf',
    artefact_name: 'PDF',
    sort_order: 9999,
    rendering_pattern: 'pdf_viewer',
    canonical_artefact_type: 'pdf',
    version_id: null,
    version_number: null,
    generated_at: null,
    generated_by_email_snapshot: null,
    content_metadata: null,
    model_code: null,
    model_name: null,
  })

  return list
}

// ---- activeArtefact.js -----------------------------------------------------

export type RegisterColumn = { key: string; label?: string }
export type RegisterRow = Record<string, unknown>

export type ActiveArtefactBase = {
  artefact_code: string
  artefact_name: string
  rendering_pattern: string | null
  canonical_artefact_type: string | null
  version_number: number | null
  generated_at: string | null
  generated_by_email_snapshot: string | null
  model_code: string | null
  model_name: string | null
}

export type ActiveArtefactDynamic = ActiveArtefactBase & {
  pattern: 'dynamic_register'
  columns: RegisterColumn[]
  rows: RegisterRow[]
  summary: string
  footer_note: string
}

export type ActiveArtefactEvidence = ActiveArtefactBase & {
  pattern: 'register_table'
  section_1: { intro: string; rows: RegisterRow[] }
  section_2: { intro: string; rows: RegisterRow[] }
  section_3: { intro: string; rows: RegisterRow[] }
}

export type ActiveArtefactNarrative = ActiveArtefactBase & {
  pattern: 'narrative'
  sections: { section_key: string; section_title: string; narrative: string; bullets: string[] }[]
}

export type ActiveArtefactPdf = ActiveArtefactBase & { pattern: 'pdf_viewer' }
export type ActiveArtefactUnknown = ActiveArtefactBase & { pattern: 'unknown' }
export type ActiveArtefactEmpty = { pattern: 'empty'; artefact_name: string; artefact_code: ''; sections: [] }

export type ActiveArtefact =
  | ActiveArtefactDynamic
  | ActiveArtefactEvidence
  | ActiveArtefactNarrative
  | ActiveArtefactPdf
  | ActiveArtefactUnknown
  | ActiveArtefactEmpty

export function buildActiveArtefact(
  orderedList: OrderedArtefact[],
  selectedArtefactCode: string | null,
): ActiveArtefact {
  const code = (selectedArtefactCode || '').toString().toLowerCase()
  const row = orderedList.find((r) => r.artefact_code === code) || orderedList[0] || null

  if (!row) {
    return { pattern: 'empty', artefact_name: '', artefact_code: '', sections: [] }
  }

  const cm = (row.content_metadata && typeof row.content_metadata === 'object'
    ? (row.content_metadata as Record<string, unknown>)
    : {}) as Record<string, unknown>

  const base: ActiveArtefactBase = {
    artefact_code: row.artefact_code,
    artefact_name: row.artefact_name,
    rendering_pattern: row.rendering_pattern,
    canonical_artefact_type: row.canonical_artefact_type,
    version_number: row.version_number,
    generated_at: row.generated_at,
    generated_by_email_snapshot: row.generated_by_email_snapshot,
    model_code: row.model_code,
    model_name: row.model_name,
  }

  const asDynamicRegister = (): ActiveArtefactDynamic => ({
    ...base,
    pattern: 'dynamic_register',
    columns: Array.isArray(cm['columns']) ? (cm['columns'] as RegisterColumn[]) : [],
    rows: Array.isArray(cm['rows']) ? (cm['rows'] as RegisterRow[]) : [],
    summary: (cm['summary'] as string | undefined) || '',
    footer_note: (cm['footer_note'] as string | undefined) || '',
  })

  const asEvidenceRegister = (): ActiveArtefactEvidence => ({
    ...base,
    pattern: 'register_table',
    section_1: (cm['section_1'] as ActiveArtefactEvidence['section_1']) || { intro: '', rows: [] },
    section_2: (cm['section_2'] as ActiveArtefactEvidence['section_2']) || { intro: '', rows: [] },
    section_3: (cm['section_3'] as ActiveArtefactEvidence['section_3']) || { intro: '', rows: [] },
  })

  if (row.rendering_pattern === 'register_table') {
    if (row.canonical_artefact_type === 'derivation_evaluation') return asEvidenceRegister()
    return asDynamicRegister()
  }

  if (row.rendering_pattern === 'dynamic_register') {
    return asDynamicRegister()
  }

  if (row.rendering_pattern === 'narrative') {
    const sections = Object.entries(cm).map(([key, value]) => {
      const v = (value && typeof value === 'object' ? value : {}) as Record<string, unknown>
      return {
        section_key: key,
        section_title: key
          .replace(/_/g, ' ')
          .replace(/\b\w/g, (c) => c.toUpperCase()),
        narrative: (v['narrative'] as string | undefined) || '',
        bullets: Array.isArray(v['bullets']) ? (v['bullets'] as string[]) : [],
      }
    })
    return { ...base, pattern: 'narrative', sections }
  }

  if (row.rendering_pattern === 'pdf_viewer') {
    return { ...base, pattern: 'pdf_viewer' }
  }

  return { ...base, pattern: 'unknown' }
}

// ---- viewerStatesByType.js -------------------------------------------------

export type ViewerState = {
  state: 'not_selected' | 'loading' | 'complete' | 'generating' | 'failed' | 'missing'
  message: string
  latestRun: GenerationRunRow | null
}

export type ViewerStatesByType = Record<string, ViewerState>

const VIEWER_TYPES = ['context', 'charter', 'plan', 'resources', 'risks', 'financials', 'pdf'] as const

export function buildViewerStatesByType(input: {
  runs: GenerationRunRow[] | null | undefined
  artefactMap: ArtefactMap
  selectedProjectId: string | null
  pageLoading: boolean
  manualGenerating: boolean
}): ViewerStatesByType {
  const runs = Array.isArray(input.runs) ? input.runs : []
  const selectedEntityId = input.selectedProjectId
  const selectedEntityType = 'Project'

  const relevantRuns = runs
    .filter((r) => String(r.entity_type || '') === selectedEntityType && String(r.entity_id || '') === String(selectedEntityId || ''))
    .sort((a, b) => {
      const bTime = new Date(b.created_at || b.started_at || 0).getTime()
      const aTime = new Date(a.created_at || a.started_at || 0).getTime()
      return bTime - aTime
    })

  const latestRun = relevantRuns[0] || null
  const latestStatus = String(latestRun?.status || '').toLowerCase()
  const runningStatuses = ['running', 'pending', 'queued', 'in_progress']

  const result: ViewerStatesByType = {}
  for (const type of VIEWER_TYPES) {
    const artefact = input.artefactMap[type] || null

    let state: ViewerState['state'] = 'complete'
    let message = ''

    if (!selectedEntityId) {
      state = 'not_selected'
      message = 'Select a project to view generated artefacts.'
    } else if (input.pageLoading) {
      state = 'loading'
      message = 'Loading latest artefacts...'
    } else if (artefact) {
      state = 'complete'
      message = ''
    } else if (input.manualGenerating || runningStatuses.includes(latestStatus)) {
      state = 'generating'
      message = 'Generation in progress. Artefacts will appear shortly.'
    } else if (latestStatus === 'failed' || latestStatus === 'error') {
      state = 'failed'
      message = 'Latest generation failed. Check the run status, then regenerate if needed.'
    } else {
      state = 'missing'
      message = type === 'pdf'
        ? 'No current PDF is available for this project.'
        : `No current ${type} artefact is available for this project.`
    }

    result[type] = { state, message, latestRun }
  }
  return result
}

// ---- latestRunForSelectedProject.js ----------------------------------------

export function pickLatestRunForProject(
  runs: GenerationRunRow[] | null | undefined,
  selectedProjectId: string | null,
): GenerationRunRow | null {
  if (!selectedProjectId) return null
  const list = Array.isArray(runs) ? runs : []
  const relevant = list
    .filter((r) => String(r.entity_type || '') === 'Project' && String(r.entity_id || '') === String(selectedProjectId))
    .sort((a, b) => {
      const bTime = new Date(b.created_at || b.started_at || 0).getTime()
      const aTime = new Date(a.created_at || a.started_at || 0).getTime()
      return bTime - aTime
    })
  return relevant[0] || null
}

// ---- shared time formatter -------------------------------------------------

export function formatGeneratedAt(iso: string | null | undefined): string {
  if (!iso) return 'Unknown time'
  const dt = new Date(iso)
  if (Number.isNaN(dt.getTime())) return 'Unknown time'
  const pad = (n: number) => String(n).padStart(2, '0')
  return `${pad(dt.getDate())}-${pad(dt.getMonth() + 1)}-${String(dt.getFullYear()).slice(-2)} ${pad(dt.getHours())}:${pad(dt.getMinutes())}`
}
