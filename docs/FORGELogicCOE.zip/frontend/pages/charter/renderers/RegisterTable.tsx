import type { ReactNode } from 'react'

// Port of /context/linked-classic-app/src/registerTableRenderer.rsx — a
// three-section "FORGE Logic built this pack" observations register backed by
// `derivation_evaluation` content metadata.

import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '../../../lib/shadcn/table'
import { Badge } from '../../../lib/shadcn/badge'
import type { ActiveArtefactEvidence } from '../derivations'

type ColumnDef = {
  key: string
  label: string
  render?: (value: unknown, row: Record<string, unknown>, artefact: ActiveArtefactEvidence) => ReactNode
}

function startCase(input: unknown): string {
  const s = String(input ?? '').replace(/[_-]+/g, ' ').trim()
  if (!s) return ''
  return s
    .split(/\s+/)
    .map((w) => w.charAt(0).toUpperCase() + w.slice(1).toLowerCase())
    .join(' ')
}

function StringCell({ value }: { value: unknown }) {
  if (value === null || value === undefined || value === '') return <span className="text-muted-foreground">—</span>
  return <span>{String(value)}</span>
}

function TagCell({ value }: { value: unknown }) {
  const label = startCase(value)
  if (!label) return <span className="text-muted-foreground">—</span>
  return <Badge variant="secondary">{label}</Badge>
}

const SECTION_1_COLUMNS: ColumnDef[] = [
  { key: 'artefact_name', label: 'Artefact name', render: (v) => <StringCell value={v} /> },
  { key: 'rationale', label: 'Rationale', render: (v) => <StringCell value={v} /> },
  { key: 'evidence_strength', label: 'Evidence strength', render: (v) => <TagCell value={v} /> },
]

const SECTION_2_COLUMNS: ColumnDef[] = [
  { key: 'claim', label: 'Claim', render: (v) => <StringCell value={v} /> },
  { key: 'location', label: 'Location', render: (v) => <StringCell value={v} /> },
  {
    key: 'inference_source',
    label: 'Inference source',
    render: (v, _row, artefact) => {
      const text = String(v ?? '').trim()
      if (text === 'From the methodology' && artefact.model_name) {
        return <span>From the {artefact.model_name} methodology</span>
      }
      return <StringCell value={v} />
    },
  },
]

const SECTION_3_COLUMNS: ColumnDef[] = [
  { key: 'input_field', label: 'Input field', render: (v) => <StringCell value={v} /> },
  { key: 'what_was_supplied', label: 'What was supplied', render: (v) => <TagCell value={v} /> },
  { key: 'how_it_shapes_output', label: 'How it shapes output', render: (v) => <StringCell value={v} /> },
  { key: 'what_would_strengthen', label: 'What would strengthen it', render: (v) => <StringCell value={v} /> },
]

function Section({
  heading,
  intro,
  columns,
  rows,
  artefact,
}: {
  heading: string
  intro: string
  columns: ColumnDef[]
  rows: Record<string, unknown>[]
  artefact: ActiveArtefactEvidence
}) {
  return (
    <section className="space-y-3">
      <h3 className="text-lg font-semibold text-foreground">{heading}</h3>
      {intro ? <p className="text-sm text-foreground leading-relaxed">{intro}</p> : null}
      <div className="rounded-md border border-border overflow-x-auto">
        <Table>
          <TableHeader>
            <TableRow>
              {columns.map((c) => (
                <TableHead key={c.key}>{c.label}</TableHead>
              ))}
            </TableRow>
          </TableHeader>
          <TableBody>
            {rows.length === 0 ? (
              <TableRow>
                <TableCell colSpan={columns.length} className="text-center italic text-muted-foreground">
                  No rows found
                </TableCell>
              </TableRow>
            ) : (
              rows.map((row, ridx) => (
                <TableRow key={ridx}>
                  {columns.map((c) => (
                    <TableCell key={c.key} className="align-top text-sm">
                      {c.render ? c.render(row[c.key], row, artefact) : <StringCell value={row[c.key]} />}
                    </TableCell>
                  ))}
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </div>
    </section>
  )
}

export default function RegisterTable({ artefact }: { artefact: ActiveArtefactEvidence }) {
  return (
    <div className="space-y-6">
      <Section
        heading="1. How FORGE Logic™ built this pack"
        intro={artefact.section_1.intro || ''}
        columns={SECTION_1_COLUMNS}
        rows={(artefact.section_1.rows as Record<string, unknown>[]) || []}
        artefact={artefact}
      />
      <Section
        heading="2. What FORGE Logic™ inferred or assumed"
        intro={artefact.section_2.intro || ''}
        columns={SECTION_2_COLUMNS}
        rows={(artefact.section_2.rows as Record<string, unknown>[]) || []}
        artefact={artefact}
      />
      <Section
        heading="3. FORGE Logic™ recommendations for next pass enhancement"
        intro={artefact.section_3.intro || ''}
        columns={SECTION_3_COLUMNS}
        rows={(artefact.section_3.rows as Record<string, unknown>[]) || []}
        artefact={artefact}
      />
    </div>
  )
}
