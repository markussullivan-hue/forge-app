import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '../../../lib/shadcn/table'
import { Markdown } from '../markdown'
import type { ActiveArtefactDynamic } from '../derivations'

function cellToString(value: unknown): string {
  if (value === null || value === undefined) return ''
  if (typeof value === 'string') return value
  if (typeof value === 'number' || typeof value === 'boolean') return String(value)
  try {
    return JSON.stringify(value)
  } catch {
    return ''
  }
}

export default function DynamicRegister({ artefact }: { artefact: ActiveArtefactDynamic }) {
  const cols = artefact.columns
  const rows = artefact.rows

  if (!cols.length) {
    return (
      <p className="text-sm italic text-muted-foreground">
        This register has no column definitions in its content.
      </p>
    )
  }

  return (
    <div className="space-y-4">
      {artefact.summary ? <Markdown>{artefact.summary}</Markdown> : null}

      <div className="rounded-md border border-border overflow-x-auto">
        <Table>
          <TableHeader>
            <TableRow>
              {cols.map((c, idx) => (
                <TableHead key={c.key || idx}>{c.label || c.key || ''}</TableHead>
              ))}
            </TableRow>
          </TableHeader>
          <TableBody>
            {rows.length === 0 ? (
              <TableRow>
                <TableCell colSpan={cols.length} className="text-center italic text-muted-foreground">
                  No entries
                </TableCell>
              </TableRow>
            ) : (
              rows.map((row, ridx) => (
                <TableRow key={ridx}>
                  {cols.map((c, cidx) => (
                    <TableCell key={`${ridx}-${c.key || cidx}`} className="align-top text-sm">
                      {cellToString(row[c.key])}
                    </TableCell>
                  ))}
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </div>

      {artefact.footer_note ? (
        <p className="text-xs italic text-muted-foreground">{artefact.footer_note}</p>
      ) : null}
    </div>
  )
}
