import { Fragment } from 'react'
import { Markdown } from '../markdown'
import type { ActiveArtefactNarrative } from '../derivations'

export default function Narrative({ artefact }: { artefact: ActiveArtefactNarrative }) {
  if (!artefact.sections.length) {
    return <p className="text-sm italic text-muted-foreground">No narrative content available.</p>
  }

  return (
    <div className="space-y-6">
      {artefact.sections.map((s, idx) => (
        <Fragment key={s.section_key || idx}>
          {idx > 0 ? <hr className="border-border" /> : null}
          <div className="space-y-2">
            <h3 className="text-lg font-semibold text-foreground">{s.section_title}</h3>
            {s.narrative ? <Markdown>{s.narrative}</Markdown> : null}
            {s.bullets.length ? (
              <ul className="list-disc pl-6 text-sm text-foreground space-y-1">
                {s.bullets.map((b, bidx) => (
                  <li key={bidx}>{b}</li>
                ))}
              </ul>
            ) : null}
          </div>
        </Fragment>
      ))}
    </div>
  )
}
