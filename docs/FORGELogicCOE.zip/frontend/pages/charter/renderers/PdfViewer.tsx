import { Download, ExternalLink, FileText } from 'lucide-react'
import { Button } from '../../../lib/shadcn/button'
import { Card, CardContent } from '../../../lib/shadcn/card'

export type PdfRow = {
  pdfmonkey_preview_url?: string | null
  pdfmonkey_download_url?: string | null
  pdfmonkey_filename?: string | null
  pdfmonkey_status?: string | null
  pdfmonkey_failure_cause?: string | null
  run_completed_at?: string | null
}

export default function PdfViewer({ pdf }: { pdf: PdfRow | null }) {
  const previewUrl = pdf?.pdfmonkey_preview_url ?? null
  const downloadUrl = pdf?.pdfmonkey_download_url ?? null

  const fallbackMessage = (() => {
    if (!pdf) return 'No PDF has been generated for this project yet.'
    if (!previewUrl) {
      const cause = pdf.pdfmonkey_failure_cause ? ` — ${pdf.pdfmonkey_failure_cause}` : ''
      return `PDF preview is not available.${cause}`
    }
    return ''
  })()

  return (
    <div className="space-y-4">
      <Card>
        <CardContent className="p-4 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
          <div className="flex items-center gap-3 text-sm">
            <FileText className="w-5 h-5 text-muted-foreground" />
            <div>
              <div className="font-medium text-foreground">
                {pdf?.pdfmonkey_filename || 'Generated PDF'}
              </div>
              {pdf?.pdfmonkey_status ? (
                <div className="text-xs text-muted-foreground">Status: {pdf.pdfmonkey_status}</div>
              ) : null}
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Button
              variant="outline"
              size="sm"
              disabled={!previewUrl}
              onClick={() => {
                if (previewUrl) window.open(previewUrl, '_blank', 'noopener,noreferrer')
              }}
            >
              <ExternalLink className="w-4 h-4 mr-1" /> Preview
            </Button>
            <Button
              size="sm"
              disabled={!downloadUrl}
              onClick={() => {
                if (downloadUrl) window.open(downloadUrl, '_blank', 'noopener,noreferrer')
              }}
            >
              <Download className="w-4 h-4 mr-1" /> Download
            </Button>
          </div>
        </CardContent>
      </Card>

      {previewUrl ? (
        <div className="w-full border border-border rounded-lg overflow-hidden bg-muted">
          <iframe
            src={previewUrl}
            title="PDF preview"
            className="w-full h-[700px] bg-background"
          />
        </div>
      ) : (
        <div className="text-sm italic text-muted-foreground border border-dashed border-border rounded-md p-6">
          {fallbackMessage}
        </div>
      )}
    </div>
  )
}
