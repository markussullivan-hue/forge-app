import { useState, type FormEvent } from 'react'
import { Link } from 'react-router-dom'
import { User, Mail, KeyRound, Building2, Eye, EyeOff } from 'lucide-react'
import { toast } from 'sonner'
import { useBackendFunction } from '../hooks/useBackendFunction'
import { Card, CardContent, CardHeader, CardTitle } from '../lib/shadcn/card'
import { Button } from '../lib/shadcn/button'
import { Input } from '../lib/shadcn/input'
import { Label } from '../lib/shadcn/label'
import Logo from '../components/Logo'

const EMAIL_RE = /^[^@\s]+@[^@\s]+\.[^@\s]+$/
const MIN_PW_LENGTH = 8

type Status = 'ok' | 'email_exists' | 'org_not_found' | 'org_ambiguous' | string

function handleSignupResult(status: Status | null, clearFields: () => void) {
  switch (status) {
    case 'ok':
      toast.success('Account created', {
        description: 'Check your email to verify your account.',
        duration: 6000,
      })
      clearFields()
      break
    case 'email_exists':
      toast.warning('Email already registered', {
        description: 'An account with this email already exists. Try logging in instead.',
        duration: 6000,
      })
      break
    case 'org_not_found':
      toast.warning('Organisation not found', {
        description: "We couldn't find that organisation. Check the name and try again.",
        duration: 6000,
      })
      break
    case 'org_ambiguous':
      toast.warning('Organisation name not unique', {
        description: 'That name matches more than one organisation. Please contact your administrator.',
        duration: 6000,
      })
      break
    default:
      toast.error('Sign-up failed', {
        description: 'Something went wrong. Please try again.',
        duration: 6000,
      })
      break
  }
}

export default function SignUpPage() {
  const signup = useBackendFunction('/backend/auth/signup.ts')

  const [fullName, setFullName] = useState('')
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [orgName, setOrgName] = useState('')
  const [showPassword, setShowPassword] = useState(false)
  const [submitting, setSubmitting] = useState(false)

  const clearFields = () => {
    setFullName('')
    setEmail('')
    setPassword('')
    setOrgName('')
  }

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault()
    const name = fullName.trim()
    const trimmedEmail = email.trim()
    const org = orgName.trim()

    if (!name || !trimmedEmail || !password || !org) {
      toast.warning('Missing fields', {
        description: 'Please complete all fields.',
        duration: 5000,
      })
      return
    }
    if (!EMAIL_RE.test(trimmedEmail)) {
      toast.warning('Invalid email', {
        description: 'Please enter a valid email address.',
        duration: 5000,
      })
      return
    }
    if (password.length < MIN_PW_LENGTH) {
      toast.warning('Password too short', {
        description: `Password must be at least ${MIN_PW_LENGTH} characters.`,
        duration: 5000,
      })
      return
    }

    setSubmitting(true)
    try {
      const result = await signup
        .trigger({
          full_name: name,
          email: trimmedEmail,
          password,
          org_name: org,
        })
        .result
      const status =
        result && typeof result === 'object' && 'status' in result
          ? ((result as { status?: string }).status ?? null)
          : null
      handleSignupResult(status, clearFields)
    } catch {
      handleSignupResult(null, clearFields)
    } finally {
      setSubmitting(false)
    }
  }

  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-white dark:bg-black text-foreground px-4 py-8 gap-6">
      <Logo size="lg" />
      <Card className="w-full max-w-md shadow-retool-md">
        <CardHeader className="text-center">
          <CardTitle className="text-2xl font-bold">Sign up</CardTitle>
        </CardHeader>
        <CardContent>
          <form className="space-y-4" onSubmit={handleSubmit} noValidate>
            <div className="space-y-2">
              <Label htmlFor="signup-name">Full name</Label>
              <div className="relative">
                <User className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground pointer-events-none" />
                <Input
                  id="signup-name"
                  type="text"
                  autoComplete="name"
                  placeholder="Enter name"
                  value={fullName}
                  onChange={(e) => setFullName(e.target.value)}
                  disabled={submitting}
                  className="pl-9"
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="signup-email">Email</Label>
              <div className="relative">
                <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground pointer-events-none" />
                <Input
                  id="signup-email"
                  type="email"
                  autoComplete="email"
                  placeholder="you@example.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  disabled={submitting}
                  className="pl-9"
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="signup-password">Password</Label>
              <div className="relative">
                <KeyRound className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground pointer-events-none" />
                <Input
                  id="signup-password"
                  type={showPassword ? 'text' : 'password'}
                  autoComplete="new-password"
                  placeholder="••••••••••"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  disabled={submitting}
                  className="pl-9 pr-10"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword((v) => !v)}
                  className="absolute inset-y-0 right-0 flex items-center px-3 text-muted-foreground hover:text-foreground transition-colors"
                  aria-label={showPassword ? 'Hide password' : 'Show password'}
                  tabIndex={-1}
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="signup-org">Organisation name</Label>
              <div className="relative">
                <Building2 className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground pointer-events-none" />
                <Input
                  id="signup-org"
                  type="text"
                  autoComplete="organization"
                  placeholder="Enter value"
                  value={orgName}
                  onChange={(e) => setOrgName(e.target.value)}
                  disabled={submitting}
                  className="pl-9"
                />
              </div>
            </div>

            <Button type="submit" className="w-full" disabled={submitting}>
              {submitting ? 'Creating account...' : 'Create account'}
            </Button>

            <p className="text-sm text-center text-muted-foreground pt-2">
              Already have an account?{' '}
              <Link to="/login" className="text-primary hover:underline">
                Sign in
              </Link>
            </p>
          </form>
        </CardContent>
      </Card>
    </div>
  )
}
